export interface Quote {
  id: number;
  text: string;
  category: 'Harapan' | 'Semangat' | 'Kebaikan' | 'Persahabatan' | 'Mimpi' | 'Ketenangan' | 'Senyuman';
  author?: string;
}

export interface PhotoItem {
  id: string;
  url: string;
  title: string;
  caption: string;
  dateTag: string;
  location?: string;
}

export interface InteractiveItem {
  id: string;
  type: 'star' | 'butterfly' | 'flower' | 'cloud' | 'firefly';
  title: string;
  content: string;
  icon: string;
}

export interface PoemItem {
  title: string;
  type: 'Poetry' | 'Literature';
  subtitle: string;
  stanzas: string[];
  note: string;
}
