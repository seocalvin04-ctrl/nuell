import React, { useState } from 'react';
import { LoadingScreen } from './components/LoadingScreen';
import { OpeningCinematic } from './components/OpeningCinematic';
import { HeartBurstTransition } from './components/HeartBurstTransition';
import { BackgroundEffects } from './components/BackgroundEffects';
import { AudioPlayer } from './components/AudioPlayer';
import { CuteCharacter } from './components/CuteCharacter';
import { LongMessageSection } from './components/LongMessageSection';
import { PhotoGallery } from './components/PhotoGallery';
import { LiteraturePoetrySection } from './components/LiteraturePoetrySection';
import { QuoteCarousel } from './components/QuoteCarousel';
import { MicroInteractions } from './components/MicroInteractions';
import { BirthdayWishTool } from './components/BirthdayWishTool';
import { CinematicEnding } from './components/CinematicEnding';
import { AUDIO_URL } from './data/content';
import { Sparkles, Mail, Camera, BookOpen, Quote as QuoteIcon, Gift, Calendar } from 'lucide-react';

export const App: React.FC = () => {
  const [appState, setAppState] = useState<'loading' | 'opening' | 'transitioning' | 'surprise'>('loading');
  const [userName, setUserName] = useState<string>('');

  const handleLoadingComplete = () => {
    setAppState('opening');
  };

  const handleOpenSurprise = () => {
    setAppState('transitioning');
  };

  const handleTransitionEnd = () => {
    setAppState('surprise');
  };

  const handleReplay = () => {
    setAppState('loading');
  };

  const scrollToSection = (id: string) => {
    const el = document.getElementById(id);
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="relative min-h-screen text-pink-950 bg-[#fff0f5] overflow-x-hidden selection:bg-pink-300 selection:text-pink-900">
      {/* Background Interactive Particles & Aurora */}
      <BackgroundEffects theme={appState === 'surprise' ? 'soft-pink' : 'soft-pink'} />

      {/* Persistent Audio Player */}
      <AudioPlayer src={AUDIO_URL} autoPlayPrompt={true} />

      {/* Step 1: Cute Mascot Loading Screen */}
      {appState === 'loading' && (
        <LoadingScreen onComplete={handleLoadingComplete} />
      )}

      {/* Step 2: Cinematic Opening Reveal */}
      {appState === 'opening' && (
        <OpeningCinematic onOpenSurprise={handleOpenSurprise} />
      )}

      {/* Step 3: Full Screen Heart Burst / Firecrackers Transition */}
      <HeartBurstTransition
        isActive={appState === 'transitioning'}
        onAnimationEnd={handleTransitionEnd}
      />

      {/* Step 4: Main Interactive Surprise Experience */}
      {appState === 'surprise' && (
        <div className="relative z-10 animate-fade-in pb-20">
          {/* Interactive Floating Teddy & Bunny Mascot */}
          <CuteCharacter />

          {/* Top Hero Banner */}
          <header className="relative pt-12 pb-8 px-4 text-center">
            <div className="max-w-3xl mx-auto flex flex-col items-center">
              {/* Badge */}
              <div className="inline-flex items-center gap-2 px-5 py-2 rounded-full bg-white/80 backdrop-blur-md border border-pink-200 shadow-md text-pink-700 text-xs sm:text-sm font-bold uppercase tracking-wider mb-4 animate-float-slow">
                <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
                <span>A Little Surprise Just For You 🤍🌸</span>
                <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
              </div>

              <h1 className="text-4xl sm:text-6xl font-serif-title font-extrabold text-pink-900 tracking-tight leading-tight drop-shadow-sm">
                Kejutan Manis & Penuh Kehangatan ✨
              </h1>

              <p className="mt-3 text-base sm:text-lg text-pink-700 font-handwriting text-2xl max-w-lg">
                "Dibuat khusus untuk membawa senyuman di harimu, {userName || 'Kamu'}." 🌸
              </p>

              {/* Quick Jump Navigation Pill Bar */}
              <nav className="mt-8 flex flex-wrap justify-center gap-2 max-w-xl">
                <button
                  onClick={() => scrollToSection('surat')}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/90 hover:bg-white text-pink-800 text-xs font-bold border border-pink-200 shadow-sm transition transform hover:scale-105 cursor-pointer"
                >
                  <Mail className="w-3.5 h-3.5 text-pink-500" />
                  <span>Surat Tulus</span>
                </button>
                <button
                  onClick={() => scrollToSection('galeri')}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/90 hover:bg-white text-pink-800 text-xs font-bold border border-pink-200 shadow-sm transition transform hover:scale-105 cursor-pointer"
                >
                  <Camera className="w-3.5 h-3.5 text-pink-500" />
                  <span>Galeri Photo</span>
                </button>
                <button
                  onClick={() => scrollToSection('sastra')}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/90 hover:bg-white text-pink-800 text-xs font-bold border border-pink-200 shadow-sm transition transform hover:scale-105 cursor-pointer"
                >
                  <BookOpen className="w-3.5 h-3.5 text-pink-500" />
                  <span>Puisi & Sastra</span>
                </button>
                <button
                  onClick={() => scrollToSection('quotes')}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/90 hover:bg-white text-pink-800 text-xs font-bold border border-pink-200 shadow-sm transition transform hover:scale-105 cursor-pointer"
                >
                  <QuoteIcon className="w-3.5 h-3.5 text-pink-500" />
                  <span>Quote 50+</span>
                </button>
                <button
                  onClick={() => scrollToSection('interaktif')}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/90 hover:bg-white text-pink-800 text-xs font-bold border border-pink-200 shadow-sm transition transform hover:scale-105 cursor-pointer"
                >
                  <Gift className="w-3.5 h-3.5 text-pink-500" />
                  <span>Mini Surprise</span>
                </button>
                <button
                  onClick={() => scrollToSection('waktu')}
                  className="flex items-center gap-1.5 px-4 py-2 rounded-full bg-white/90 hover:bg-white text-pink-800 text-xs font-bold border border-pink-200 shadow-sm transition transform hover:scale-105 cursor-pointer"
                >
                  <Calendar className="w-3.5 h-3.5 text-pink-500" />
                  <span>Kalkulator Waktu</span>
                </button>
              </nav>
            </div>
          </header>

          {/* Section 1: Main Long Message */}
          <section id="surat">
            <LongMessageSection onNameChange={(n) => setUserName(n)} />
          </section>

          {/* Section 2: Photo Gallery */}
          <section id="galeri">
            <PhotoGallery />
          </section>

          {/* Section 3: Literature & Poetry */}
          <section id="sastra">
            <LiteraturePoetrySection />
          </section>

          {/* Section 4: 50+ Quotes Carousel */}
          <section id="quotes">
            <QuoteCarousel />
          </section>

          {/* Section 5: Micro Interactions */}
          <section id="interaktif">
            <MicroInteractions />
          </section>

          {/* Section 6: Time of Birth & Special Day Counter */}
          <section id="waktu">
            <BirthdayWishTool />
          </section>

          {/* Section 7: Cinematic Ending */}
          <CinematicEnding onReplay={handleReplay} />
        </div>
      )}
    </div>
  );
};

export default App;
