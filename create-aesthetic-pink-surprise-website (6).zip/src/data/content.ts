import { Quote, PhotoItem, InteractiveItem, PoemItem } from '../types';

export const AUDIO_URL = "https://cdn.jsdelivr.net/gh/seocalvin04-ctrl/nuell@main/HIVI!%20-%20Pelangi%20-%20GuanPetteson.mp3";

export const GALLERY_PHOTOS: PhotoItem[] = [
  {
    id: "1",
    url: "https://cdn.jsdelivr.net/gh/seocalvin04-ctrl/nuell@main/d2c40ee205e4147038aa9be54b20265c.jpg",
    title: "Momen Lembut & Hangat 🌸",
    caption: "Setiap senyuman yang terukir adalah potongan kebahagiaan sederhana yang membuat hari menjadi lebih indah.",
    dateTag: "Special Collection I",
    location: "Sweet Memories"
  },
  {
    id: "2",
    url: "https://cdn.jsdelivr.net/gh/seocalvin04-ctrl/nuell@main/a7334a64730b6bc107159e82a9da373d.jpg",
    title: "Cahaya Dalam Hari 🤍",
    caption: "Seperti warna pelangi setelah hujan, kebaikan hatimu membawa ketenangan dan keceriaan tersendiri.",
    dateTag: "Special Collection II",
    location: "Warm Horizons"
  },
  {
    id: "3",
    url: "https://cdn.jsdelivr.net/gh/seocalvin04-ctrl/nuell@main/1b787d0c6886970883e9a53b13b0b796.jpg",
    title: "Langkah & Harapan 🌷",
    caption: "Tetaplah melangkah dengan senyuman tulus. Dunia selalu membutuhkan jiwa senyaman dirimu.",
    dateTag: "Special Collection III",
    location: "Dreamy Pathway"
  }
];

export const QUOTES_LIST: Quote[] = [
  { id: 1, text: "Langkah kecil hari ini mungkin menjadi cerita indah yang paling kamu syukuri suatu hari nanti.", category: "Harapan" },
  { id: 2, text: "Tidak semua hari harus berjalan sempurna, cukuplah hari ini kamu sudah berusaha sebaik mungkin.", category: "Semangat" },
  { id: 3, text: "Kebaikan tulus adalah bahasa yang bisa didengar oleh yang tak bisa mendengar dan dilihat oleh yang tak bisa melihat.", category: "Kebaikan" },
  { id: 4, text: "Senyumanmu mungkin hal paling sederhana bagimu, namun bagi dunia di sekitarmu, itu adalah kehangatan.", category: "Senyuman" },
  { id: 5, text: "A single kind message can change someone's entire day with unspoken warmth.", category: "Kebaikan" },
  { id: 6, text: "Langit tidak pernah lupa caranya bersinar, bahkan saat tertutup awan paling tebal sekalipun.", category: "Harapan" },
  { id: 7, text: "Istirahatlah sejenak. Kamu tidak perlu terburu-buru untuk membuktikan apa pun kepada dunia.", category: "Ketenangan" },
  { id: 8, text: "Setiap bunga mekar pada waktunya sendiri, begitu pula dengan impian dan perjalanan hidupmu.", category: "Mimpi" },
  { id: 9, text: "You are stronger than the worries of today and brighter than the stars of tomorrow.", category: "Semangat" },
  { id: 10, text: "Kadang, kejutan sederhana lebih lama tinggal di ingatan daripada hadiah yang paling mewah.", category: "Persahabatan" },
  { id: 11, text: "Tidak ada kebaikan yang sia-sia, sekecil apa pun ketulusan yang kamu bagikan hari ini.", category: "Kebaikan" },
  { id: 12, text: "Teruslah percaya pada mimpimu, sebab setiap usaha tulus tidak pernah kehilangan jalannya.", category: "Mimpi" },
  { id: 13, text: "Di balik setiap hari yang berat, selalu ada pelangi indah yang siap menyambutmu di ujung jalan.", category: "Harapan" },
  { id: 14, text: "Be gentle with yourself; you are doing the best you can in this unpredictable journey.", category: "Ketenangan" },
  { id: 15, text: "Bahkan di malam yang paling gelap, bintang-bintang tetap setia menerangi langit malam.", category: "Harapan" },
  { id: 16, text: "Senyummu adalah pengingat bahwa keindahan masih ada di sekitar kita.", category: "Senyuman" },
  { id: 17, text: "Setiap pertemuan membawa cerita, dan setiap cerita menyisakan kehangatan tersendiri.", category: "Persahabatan" },
  { id: 18, text: "May your heart always be full of peace and your days filled with sweet moments.", category: "Ketenangan" },
  { id: 19, text: "Jangan pernah meremehkan ketabahanmu sendiri, kamu telah berhasil melewati banyak hal hingga hari ini.", category: "Semangat" },
  { id: 20, text: "Kebaikan hati adalah perhiasan paling indah yang tidak pernah memudar oleh waktu.", category: "Kebaikan" },
  { id: 21, text: "Setiap napas baru di pagi hari adalah kesempatan baru untuk memulai cerita yang lebih baik.", category: "Harapan" },
  { id: 22, text: "The universe has a soft way of guiding beautiful souls to where they belong.", category: "Ketenangan" },
  { id: 23, text: "Semoga langkahmu senantiasa diringi oleh orang-orang yang tulus menyayangimu apa adanya.", category: "Persahabatan" },
  { id: 24, text: "Jangan lupa untuk tersenyum hari ini, dunia terlihat jauh lebih manis saat kamu bahagia.", category: "Senyuman" },
  { id: 25, text: "Impian besar dimulai dari ketekunan kecil yang dilakukan dengan penuh sukacita.", category: "Mimpi" },
  { id: 26, text: "Ketika lelah menyapa, peluklah dirimu sendiri dan katakan 'terima kasih sudah berjuang'.", category: "Semangat" },
  { id: 27, text: "Sincerity is an invisible bridge that connects heart to heart across distance.", category: "Kebaikan" },
  { id: 28, text: "Setiap tetes hujan yang jatuh membawa doa agar hatimu selalu dalam damai dan sejuk.", category: "Ketenangan" },
  { id: 29, text: "Hargai setiap proses, karena keberhasilan sejati terasa lebih manis saat kita tahu perjuangannya.", category: "Mimpi" },
  { id: 30, text: "Kamu berharga bukan karena apa yang kamu capai, tetapi karena keberadaanmu itu sendiri.", category: "Semangat" },
  { id: 31, text: "Keep shining your gentle light; the world is a warmer place because you exist.", category: "Harapan" },
  { id: 32, text: "Keindahan sejati berasal dari kemurnian niat dan ketulusan rasa yang ada di dalam dada.", category: "Kebaikan" },
  { id: 33, text: "Jadilah seperti bunga matahari yang selalu tahu ke mana arah cahaya berada.", category: "Harapan" },
  { id: 34, text: "Tidak perlu terburu-buru, hal-hal indah butuh waktu untuk mekar sempurna.", category: "Ketenangan" },
  { id: 35, text: "A warm word is like a gentle breeze on a sunny afternoon.", category: "Kebaikan" },
  { id: 36, text: "Setiap kenangan indah bermula dari keputusan sederhana untuk saling menghargai.", category: "Persahabatan" },
  { id: 37, text: "Semoga hari ini memberikanmu alasan untuk tertawa renyah dan merasa bersyukur.", category: "Senyuman" },
  { id: 38, text: "Kadang kala, berjalan pelan adalah cara terbaik untuk menikmati pemandangan di sekitar.", category: "Ketenangan" },
  { id: 39, text: "Never lose the child-like wonder in your heart; it makes the ordinary extraordinary.", category: "Senyuman" },
  { id: 40, text: "Setiap kata baik yang diucapkan adalah benih kebahagiaan yang akan tumbuh di kemudian hari.", category: "Kebaikan" },
  { id: 41, text: "Perjalanan ribuan mil selalu dimulai dengan satu langkah keberanian di hari ini.", category: "Mimpi" },
  { id: 42, text: "Semoga malam ini membawamu dalam tidur yang lelap dan mimpi yang sangat indah.", category: "Ketenangan" },
  { id: 43, text: "You are the author of your own story, make sure every chapter is written with love.", category: "Mimpi" },
  { id: 44, text: "Ketenangan hati tidak ditemukan di tempat yang sepi, melainkan di dalam penerimaan yang tulus.", category: "Ketenangan" },
  { id: 45, text: "Ketika kamu menebar kebaikan, kebaikan itu akan selalu menemukan jalan kembali padamu.", category: "Kebaikan" },
  { id: 46, text: "Semoga setiap doa-doamu yang sunyi didengar dan dijawab dengan cara paling indah.", category: "Harapan" },
  { id: 47, text: "Satu senyuman tulus bisa menjadi jawaban bagi hati yang sedang mencari ketenangan.", category: "Senyuman" },
  { id: 48, text: "Trust the timing of your life; everything is unfolding just as it should.", category: "Harapan" },
  { id: 49, text: "Jadilah tempat yang aman bagi impianmu sendiri sebelum membagikannya pada dunia.", category: "Mimpi" },
  { id: 50, text: "Terima kasih telah menjadi jiwa yang lembut di tengah dunia yang kadang begitu tergesa-gesa.", category: "Kebaikan" },
  { id: 51, text: "Semoga hari ini menjadi salah satu hari paling menyenangkan yang selalu kamu ingat.", category: "Harapan" },
  { id: 52, text: "Your smile is proof that happiness is sweet, pure, and contagious.", category: "Senyuman" }
];

export const INTERACTIVE_ITEMS: InteractiveItem[] = [
  {
    id: "star",
    type: "star",
    title: "⭐ Pesan Bintang Rahasia",
    content: "Di bawah hamparan bintang malam ini, ada doa hangat yang dipanjatkan agar setiap langkahmu dilingkupi kemudahan dan kebahagiaan sejati. Kamu adalah cahaya kecil yang berharga!",
    icon: "✨"
  },
  {
    id: "butterfly",
    type: "butterfly",
    title: "🦋 Pesan Kupu-Kupu Soft Pink",
    content: "Kupu-kupu terbang mengepakkan sayap dengan lembut tanpa bersuara. Begitu pula kebaikan hatimu yang hening namun memberikan kehangatan bagi siapa pun di sekitarmu.",
    icon: "🦋"
  },
  {
    id: "flower",
    type: "flower",
    title: "🌸 Bunga Mekar Musim Semi",
    content: "Bunga tidak pernah bersaing dengan bunga di sebelahnya. Ia hanya mekar dan menjadi dirinya sendiri. Teruslah mekar dengan keindahan tulusmu!",
    icon: "🌷"
  },
  {
    id: "cloud",
    type: "cloud",
    title: "☁️ Awan Harapan & Doa",
    content: "Semoga awan lembut menyerap semua rasa lelahmu hari ini, menyisa rasa tenang, damai sejahtera, dan senyuman manis saat kamu beristirahat nanti malam.",
    icon: "☁️"
  },
  {
    id: "firefly",
    type: "firefly",
    title: "💡 Kunang-Kunang Penyemangat",
    content: "Bahkan satu titik cahaya kecil di tengah kegelapan mampu memberi petunjuk jalan. Semangat yaa, perjalanannmu luar biasa indah!",
    icon: "✨"
  }
];

export const POEM_DATA: PoemItem[] = [
  {
    title: "Di Bawah Langit Lembayung",
    type: "Literature",
    subtitle: "Sebuah Karya Sastra Modern tentang Ketenangan & Ketulusan",
    stanzas: [
      "Ada waktu-waktu di mana langit sore mengajarkan kita untuk berhenti sejenak. Ketika warna merah muda berpadu dengan keemasan, embun berbisik pelan pada dedaunan yang terkulai pasrah.",
      "Kita sering kali melangkah terlalu cepat, mengejar bayang-bayang di masa depan, hingga lupa bahwa detik ini—saat ini—adalah sebuah anugerah yang patut dirayakan dengan sebuah napas lega.",
      "Tidakkah terasa menenangkan ketika mengetahui bahwa di sudut dunia yang riuh ini, ada jiwa-jiwa yang tetap memilih untuk bersikap lembut? Tanpa perlu bersuara nyaring, ketulusan senantiasa menemukan jalannya sendiri.",
      "Seperti benih yang tumbuh dalam keheningan tanah, harapan tidak pernah tergesa-gesa. Ia mekar saat waktunya tiba, di bawah naungan kasih yang melimpah dan senyuman yang menyembuhkan.",
      "Semoga dalam setiap persimpangan langkahmu, kamu senantiasa menemukan sudut tenang untuk pulang pada dirimu sendiri, membawa ketenteraman yang tidak pernah pudar oleh riuhnya zaman."
    ],
    note: "Sastra dikarang khusus untuk membawa kedamaian dan sudut pandang lembut bagi jiwa yang membaca."
  },
  {
    title: "Melodi Pelangi dan Angin Senja",
    type: "Poetry",
    subtitle: "Puisi Estetik Melodi Kasih & Harapan",
    stanzas: [
      "Hujan telah usai di ujung petang,\nMenyisa jejak embun di dedaunan,\nPelangi membentang di batas pandang,\nMembawa kedamaian yang tak terucapkan.",
      "Awan merah muda menari perlahan,\nDiiringi angin yang berbisik lembut,\nMenghapus duka dan segala beban,\nMenuntun langkah yang sempat ragu dan surut.",
      "Setiap detik adalah bait puisi,\nDitulis dengan jemari waktu yang tenang,\nSemoga hatimu selalu dipenuhi rasa damai,\nDan senyumanmu bersinar bak bintang terang.",
      "Teruslah melangkah wahai jiwa yang indah,\nDunia ini jauh lebih manis bersamamu,\nTak perlu takut pada gelapnya malam yang singgah,\nSebab esok fajar kembali menyapamu."
    ],
    note: "Setiap bait ditulis dengan nuansa puitis yang estetik dan lembut di hati."
  }
];

export const EXTRA_LONG_TEXT = `
☁️🤍🫧🧸💌🌷🌸✨🌼🕊️💐🍀🌈⭐🦋🌿🤍🤍🤍🤍🤍🤍🤍🤍🤍🤍🤍

✨ A Little Reflection for You 🤍

Sometimes, in the middle of our busy days, we forget how far we've come.
We focus so much on the hills ahead that we forget to celebrate the valleys we've already crossed.

I wanted to share this note not because today is a special holiday or a big milestone,
but simply because every ordinary day becomes extraordinary when we acknowledge the warmth around us.

You carry a gentle energy that makes people around you feel comfortable, understood, and appreciated.
In a world that is often loud and rushed, being soft-hearted is not a weakness; it is a quiet form of courage.

May you always find peace in the small things:
✨ The first sip of a warm drink on a chilly morning.
✨ The sound of rain tapping softly against the window.
✨ The unexpected smile from a stranger on the street.
✨ The quiet realization that you are exactly where you need to be.

Never doubt your worth, even when things don't go according to plan.
Storms always pass, clouds clear up, and the sun always finds its way back to shine upon you.

Always stay true to your kind heart, keep dreaming with enthusiasm, and remember that your journey is uniquely yours—beautiful, meaningful, and deeply valued. 🌸🤍✨

☁️🤍🫧🧸💌🌷🌸✨🌼🕊️💐🍀🌈⭐🦋🌿🤍🤍🤍🤍🤍🤍🤍🤍🤍🤍🤍
`;
