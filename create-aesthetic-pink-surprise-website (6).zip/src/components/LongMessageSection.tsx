import React, { useState } from 'react';
import { Heart, Copy, Check, MessageSquare, Send } from 'lucide-react';
import { EXTRA_LONG_TEXT } from '../data/content';
import confetti from 'canvas-confetti';

interface LongMessageProps {
  onNameChange?: (name: string) => void;
}

export const LongMessageSection: React.FC<LongMessageProps> = ({ onNameChange }) => {
  const [userName, setUserName] = useState<string>('');
  const [inputName, setInputName] = useState<string>('');
  const [copied, setCopied] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'main' | 'extra'>('main');

  const handleNameSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (inputName.trim()) {
      setUserName(inputName.trim());
      if (onNameChange) onNameChange(inputName.trim());
      confetti({
        particleCount: 25,
        spread: 60,
        origin: { y: 0.7 },
        colors: ['#f472b6', '#fb7185', '#ffd1dc']
      });
    }
  };

  const displayName = userName || "Kamu";

  const mainContentText = `
☁️🤍🫧🧸💌🌷🌸✨🌼🕊️💐🍀🌈⭐🦋🌿🤍🤍🤍🤍🤍🤍🤍🤍🤍🤍🤍

╔═══════༺❀༻════════╗
　　　　 ✨ A Little Surprise 🤍
　　　　   Just For You 🌸
╚═══════༺❀༻════════╝

☁️🤍🫧🧸💌🌷🌸✨

Allooooooooooooooooooooooooowwwwwwwww🤍🧸🌷🌸🫧✨💐🌼
Hayiieeeeeeeeeeeeeeeeeeeeeeeeeee☀️🤍🫧🌷🧸🌸💌✨
Eyyyyyyyyyyyyooooooooooooooooowwwwwwwww😆🤍🌸🫧💐✨

Hallooooooooooooooooooooowwwwwwwww ${displayName}... 🤭🤭🧸🌷🌼🤍
Iyaaaaaaaaaa... ${displayName}... 🤭🤍🫶🏻✨🌸

Waduhhhhh... kok rasanya agak lucu yaa kalau tiba-tiba ada pesan sepanjang ini muncul buat kamuuu? 😆🌷🧸

Siapaaaaaaaa nama kamuuuu...? 🤩👸🏻🌷🫧🤍

Boleh kenalan nggak...? Hihihiiii... 🤭✨💌

🧸🌸🫧💌🌷✨💐🤍🤍🤍🤍🤍🤍🤍🤍

Btw...

Tenang aja yaaa... 🤍🌸

Aku nulis semua ini bukan karena ada maksud yang aneh-aneh kok... 🤗😉✨

Bukan juga karena ingin mengganggu waktumu.

Dan bukan karena berharap sesuatu sebagai balasan.

Aku cuma kepikiran satu hal sederhana...

Kadang seseorang yang sedang menjalani harinya...

Butuh membaca beberapa kalimat baik.

Bukan karena hidupnya sedang buruk.

Tapi karena setiap hati tetap senang ketika diingatkan kalau dirinya berharga. 🤍🕊️🌷

🌼🫧🧸💌🌸✨🤍🤍🤍🤍🤍🤍🤍🤍

Kalau sekarang kamu sedang tersenyum...

Semoga senyum itu bertahan lebih lama lagi. 😊🤍🌸

Kalau sekarang kamu sedang capek...

Semoga sebentar lagi kamu menemukan waktu untuk beristirahat. 🫂☁️🌿

Kalau sekarang kamu sedang mengejar banyak mimpi...

Semoga satu per satu impian itu mulai mendekat ke arahmu. 🌈⭐✨

Dan kalau sekarang kamu sedang merasa sendirian...

Semoga kamu segera dipertemukan dengan orang-orang yang benar-benar tulus menyayangimu apa adanya. 🤍🧸🌷

🕊️🌸🧸🫧💌🌷💐✨🤍🤍🤍🤍🤍🤍🤍🤍

You know...? 🤍✨

Sometimes...

A single kind message can change someone's entire day.

Not because the words are magical...

But because sincerity has its own way of reaching the heart.

Maybe we'll never know what someone is silently fighting.

Maybe we'll never know how heavy their thoughts are today.

That's why...

Being kind is never a waste.

A warm word...

A sincere smile...

Or even a simple "How are you?"...

Can mean so much more than we realize. 🤍🦋🌿

🌷🧸🌸🫧💌🌼✨💐🤍🤍🤍🤍🤍🤍🤍🤍

Jadi...

Kalau hari ini ternyata berjalan sesuai harapan...

Selamat yaa... semoga kebahagiaanmu terus bertambah. 🌸🤍✨

Kalau ternyata hari ini masih terasa berat...

Nggak apa-apa...

Pelan-pelan aja.

Langit pun tidak selalu cerah setiap hari.

Tapi setelah hujan...

Selalu ada kesempatan untuk melihat pelangi lagi. 🌈🤍☁️

Dan semoga...

Apa pun yang sedang kamu perjuangkan sekarang...

Suatu hari nanti bisa membuatmu tersenyum sambil berkata,

"Ternyata aku berhasil melewati semuanya." 🤍🫂✨

🧸🌼💌🌷🫧🌸🤍🤍🤍🤍🤍🤍🤍🤍

Terima kasih yaa...

Karena sudah meluangkan sedikit waktumu membaca pesan sederhana ini. 🤍🌷

Mungkin kita belum pernah benar-benar saling mengenal.

Mungkin kita hanya dipertemukan lewat momen yang singkat.

Atau mungkin...

Ini bahkan pertama kalinya kamu membaca sesuatu seperti ini.

Tapi semoga setelah selesai membaca...

Ada sedikit rasa hangat yang tinggal di dalam hati.

Karena itu sudah lebih dari cukup. 🤍🕊️✨

🌿🧸🌸🫧💌💐🤍🤍🤍🤍🤍🤍🤍🤍

Sebelum pesan ini selesai...

Izinkan aku menitipkan doa kecil untukmu... 🤲🏻🤍

Kiranya Tuhan Yesus selalu menyertai setiap langkahmu, memberikan damai sejahtera di dalam hatimu, memberkati setiap pekerjaanmu, melindungimu dari segala hal yang buruk, menguatkanmu ketika lelah, dan memenuhi hidupmu dengan kasih serta sukacita yang tidak pernah habis.

Amin. 🤍✝️🕊️

☀️🤍🫧🌷🧸🌸✨

Take care of yourself... 🤍

Keep smiling... 😊🌸

Keep being kind... 🌷🫶🏻

Keep believing in your dreams... ⭐🌈

And never forget...

No matter where life takes you, I hope you always meet people who appreciate your heart, respect your kindness, and remind you that you are valuable just by being yourself.

Have a beautiful day, beautiful soul... 🤍🕊️🌼✨
`;

  const copyToClipboard = () => {
    navigator.clipboard.writeText(activeTab === 'main' ? mainContentText : EXTRA_LONG_TEXT);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="relative my-12 max-w-3xl mx-auto px-4">
      {/* Interactive Name Greeting Form */}
      <div className="glass-card rounded-3xl p-6 sm:p-8 mb-8 border border-white/80 shadow-xl transition-all">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-2xl bg-pink-100 flex items-center justify-center text-pink-500 shadow-sm border border-pink-200">
              <MessageSquare className="w-6 h-6 animate-pulse" />
            </div>
            <div>
              <h3 className="text-lg font-serif-title font-bold text-pink-900">
                Sapaan Personalisasi 🌸
              </h3>
              <p className="text-xs text-pink-700">
                Ketik namamu agar pesan surat menjadi lebih hangat!
              </p>
            </div>
          </div>

          <form onSubmit={handleNameSubmit} className="flex items-center gap-2 w-full sm:w-auto">
            <input
              type="text"
              placeholder="Tulis namamu di sini..."
              value={inputName}
              onChange={(e) => setInputName(e.target.value)}
              className="flex-1 sm:w-48 px-4 py-2 rounded-full bg-white/90 border border-pink-300 text-xs font-semibold text-pink-900 focus:outline-none focus:ring-2 focus:ring-pink-400"
            />
            <button
              type="submit"
              className="px-4 py-2 rounded-full bg-pink-500 hover:bg-pink-600 text-white text-xs font-bold shadow-md transition flex items-center gap-1 cursor-pointer"
            >
              <span>Simpan</span>
              <Send className="w-3.5 h-3.5" />
            </button>
          </form>
        </div>

        {userName && (
          <div className="mt-4 p-3 rounded-2xl bg-pink-50/80 border border-pink-200 text-xs font-medium text-pink-800 flex items-center justify-between">
            <span>✨ Pesan sekarang menyapa: <strong className="text-pink-600 font-bold">{userName}</strong></span>
            <button onClick={() => setUserName('')} className="text-pink-500 underline hover:text-pink-700">Reset</button>
          </div>
        )}
      </div>

      {/* Tab Selector for Main vs Additional Deep Long Text */}
      <div className="flex justify-center mb-6">
        <div className="inline-flex p-1.5 rounded-full bg-white/80 backdrop-blur-md border border-pink-200 shadow-md">
          <button
            onClick={() => setActiveTab('main')}
            className={`px-5 py-2 rounded-full text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'main' ? 'bg-gradient-to-r from-pink-500 to-rose-400 text-white shadow-sm' : 'text-pink-700 hover:bg-pink-100'
            }`}
          >
            💌 Surat Utama (Surprise Letter)
          </button>
          <button
            onClick={() => setActiveTab('extra')}
            className={`px-5 py-2 rounded-full text-xs sm:text-sm font-bold transition-all ${
              activeTab === 'extra' ? 'bg-gradient-to-r from-pink-500 to-rose-400 text-white shadow-sm' : 'text-pink-700 hover:bg-pink-100'
            }`}
          >
            🌸 Wawasan Tambahan (Reflection)
          </button>
        </div>
      </div>

      {/* Glass Card Container for Long Text */}
      <div className="relative glass-card rounded-3xl p-6 sm:p-10 border border-white/90 shadow-2xl transition-all">
        {/* Top Floating Copy Button */}
        <div className="flex items-center justify-between mb-6 pb-4 border-b border-pink-200/60">
          <div className="flex items-center gap-2">
            <Heart className="w-5 h-5 text-pink-500 fill-pink-400 animate-pulse" />
            <span className="text-xs font-bold text-pink-900 uppercase tracking-widest font-rounded">
              {activeTab === 'main' ? "Surat Tulus Untukmu" : "Warm English & Indonesian Reflection"}
            </span>
          </div>

          <button
            onClick={copyToClipboard}
            className="flex items-center gap-1.5 px-3.5 py-1.5 rounded-full bg-white/90 hover:bg-white text-pink-700 border border-pink-300 text-xs font-bold shadow-sm transition transform active:scale-95 cursor-pointer"
            title="Salin isi pesan"
          >
            {copied ? (
              <>
                <Check className="w-3.5 h-3.5 text-emerald-500" />
                <span className="text-emerald-600">Tersalin!</span>
              </>
            ) : (
              <>
                <Copy className="w-3.5 h-3.5 text-pink-500" />
                <span>Salin Teks</span>
              </>
            )}
          </button>
        </div>

        {/* Text Render Block */}
        <div className="prose prose-pink max-w-none text-pink-950 font-sans leading-relaxed text-sm sm:text-base whitespace-pre-line">
          {activeTab === 'main' ? (
            <div>
              <div className="text-center my-4 font-serif-title text-xl text-pink-900 font-bold">
                ✨ A Little Surprise 🤍 Just For You 🌸
              </div>
              {mainContentText}
            </div>
          ) : (
            <div>
              <div className="text-center my-4 font-serif-title text-xl text-pink-900 font-bold">
                ☁️ Gentle Words For A Gentle Soul 🌸
              </div>
              {EXTRA_LONG_TEXT}
            </div>
          )}
        </div>

        {/* Bottom Interactive Reactions */}
        <div className="mt-8 pt-6 border-t border-pink-200/60 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-xs font-medium text-pink-700">Kirim kehangatan balik:</span>
            <button
              onClick={() => {
                confetti({
                  particleCount: 20,
                  spread: 50,
                  colors: ['#f472b6', '#fb7185']
                });
              }}
              className="p-2 rounded-full bg-pink-100 hover:bg-pink-200 text-pink-600 transition transform hover:scale-110 active:scale-95 cursor-pointer"
              title="Kirim Cinta 💖"
            >
              💖
            </button>
            <button
              onClick={() => {
                confetti({
                  particleCount: 20,
                  spread: 50,
                  colors: ['#f59e0b', '#fde047']
                });
              }}
              className="p-2 rounded-full bg-amber-100 hover:bg-amber-200 text-amber-600 transition transform hover:scale-110 active:scale-95 cursor-pointer"
              title="Kirim Peluk 🫂"
            >
              🫂
            </button>
            <button
              onClick={() => {
                confetti({
                  particleCount: 20,
                  spread: 50,
                  colors: ['#38bdf8', '#818cf8']
                });
              }}
              className="p-2 rounded-full bg-sky-100 hover:bg-sky-200 text-sky-600 transition transform hover:scale-110 active:scale-95 cursor-pointer"
              title="Kirim Doa 🤲🏻"
            >
              🤲🏻
            </button>
          </div>

          <span className="text-xs text-pink-600 font-medium italic">
            "Sincerity has its own way of reaching the heart." 🌸
          </span>
        </div>
      </div>
    </div>
  );
};
