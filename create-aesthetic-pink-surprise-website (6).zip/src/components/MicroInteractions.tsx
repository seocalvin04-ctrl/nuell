import React, { useState } from 'react';
import { X, Gift } from 'lucide-react';
import { INTERACTIVE_ITEMS } from '../data/content';
import { InteractiveItem } from '../types';
import confetti from 'canvas-confetti';

export const MicroInteractions: React.FC = () => {
  const [selectedItem, setSelectedItem] = useState<InteractiveItem | null>(null);

  const handleTrigger = (item: InteractiveItem, e: React.MouseEvent) => {
    setSelectedItem(item);

    // Confetti from click location
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;

    confetti({
      particleCount: 20,
      spread: 60,
      origin: { x, y },
      colors: item.type === 'star' ? ['#fde047', '#f59e0b'] :
              item.type === 'butterfly' ? ['#e879f9', '#f472b6'] :
              item.type === 'flower' ? ['#f472b6', '#fb7185'] :
              item.type === 'cloud' ? ['#38bdf8', '#818cf8'] : ['#facc15', '#fef08a']
    });
  };

  return (
    <div className="relative my-16 max-w-4xl mx-auto px-4">
      {/* Section Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/80 border border-pink-300 shadow-sm text-pink-700 text-xs font-bold uppercase tracking-wider mb-3">
          <Gift className="w-3.5 h-3.5 text-pink-500 animate-bounce" />
          <span>Mini Surprises Interactive 🌸</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-serif-title font-bold text-pink-900 tracking-tight">
          Sentuh Ikon Kejutan Rahasia
        </h2>
        <p className="mt-2 text-sm text-pink-700 max-w-md mx-auto">
          Klik elemen ajaib di bawah ini untuk membocorkan pesan manis yang tersembunyi!
        </p>
      </div>

      {/* Interactive Icons Box */}
      <div className="grid grid-cols-2 sm:grid-cols-5 gap-4">
        {INTERACTIVE_ITEMS.map((item) => (
          <button
            key={item.id}
            onClick={(e) => handleTrigger(item, e)}
            className="group relative glass-card p-6 rounded-3xl border border-white/90 shadow-lg flex flex-col items-center justify-center gap-3 transition-all duration-300 transform hover:scale-105 hover:-translate-y-1 active:scale-95 cursor-pointer"
          >
            <div className="text-4xl transform group-hover:scale-125 transition-transform duration-300 animate-float-slow">
              {item.icon}
            </div>
            <span className="text-xs font-bold text-pink-900 text-center font-rounded group-hover:text-pink-600 transition">
              {item.title.split(' ')[1] || item.title}
            </span>
            <span className="text-[10px] text-pink-600 font-medium">Klik Aku ✨</span>
          </button>
        ))}
      </div>

      {/* Interactive Modal Popup */}
      {selectedItem && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/50 backdrop-blur-md animate-fade-in">
          <div className="relative max-w-md w-full bg-white/95 rounded-3xl p-6 sm:p-8 border border-pink-200 shadow-2xl text-center transform animate-float-bounce">
            <button
              onClick={() => setSelectedItem(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-pink-100 hover:bg-pink-200 text-pink-800 transition z-10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="text-5xl mb-4 animate-bounce">
              {selectedItem.icon}
            </div>

            <h3 className="text-2xl font-serif-title font-bold text-pink-900 mb-3">
              {selectedItem.title}
            </h3>

            <p className="text-sm text-pink-800 leading-relaxed font-medium bg-pink-50/80 p-4 rounded-2xl border border-pink-200/60 mb-6">
              "{selectedItem.content}"
            </p>

            <button
              onClick={() => setSelectedItem(null)}
              className="px-6 py-2.5 rounded-full bg-gradient-to-r from-pink-500 to-rose-400 text-white text-xs font-bold shadow-md hover:shadow-lg transition cursor-pointer"
            >
              Terima Kasih ✨
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
