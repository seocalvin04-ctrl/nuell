import React, { useState } from 'react';
import { BookOpen, Sparkles, Feather, Bookmark, Heart } from 'lucide-react';
import { POEM_DATA } from '../data/content';

export const LiteraturePoetrySection: React.FC = () => {
  const [activePoemIndex, setActivePoemIndex] = useState<number>(0);
  const [bookmarked, setBookmarked] = useState<boolean>(false);

  const currentItem = POEM_DATA[activePoemIndex];

  return (
    <div className="relative my-16 max-w-4xl mx-auto px-4">
      {/* Section Header */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/80 border border-pink-300 shadow-sm text-pink-700 text-xs font-bold uppercase tracking-wider mb-3">
          <Feather className="w-3.5 h-3.5 text-pink-500" />
          <span>Karya Sastra & Puisi Modern 🌸</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-serif-title font-bold text-pink-900 tracking-tight">
          Sentuhan Kalimat & Bait Puitis
        </h2>
        <p className="mt-2 text-sm text-pink-700 max-w-md mx-auto">
          Sastra modern & puisi orisinal yang ditulis dengan hati yang tenang dan tulus.
        </p>
      </div>

      {/* Selector Tabs */}
      <div className="flex justify-center gap-3 mb-8">
        {POEM_DATA.map((item, idx) => (
          <button
            key={idx}
            onClick={() => {
              setActivePoemIndex(idx);
              setBookmarked(false);
            }}
            className={`flex items-center gap-2 px-6 py-3 rounded-2xl text-xs sm:text-sm font-bold transition-all shadow-sm cursor-pointer ${
              activePoemIndex === idx
                ? 'bg-gradient-to-r from-pink-500 to-rose-400 text-white shadow-lg shadow-pink-300/50 scale-105'
                : 'bg-white/80 hover:bg-white text-pink-800 border border-pink-200'
            }`}
          >
            <BookOpen className="w-4 h-4" />
            <span>{item.type}: {item.title}</span>
          </button>
        ))}
      </div>

      {/* Main Glass Book Card */}
      <div className="relative glass-card rounded-3xl p-6 sm:p-12 border border-white/90 shadow-2xl transition-all">
        {/* Decorative corner bookmarks */}
        <div className="absolute top-6 right-6">
          <button
            onClick={() => setBookmarked(!bookmarked)}
            className={`p-2.5 rounded-full transition cursor-pointer ${
              bookmarked ? 'bg-pink-500 text-white shadow-md' : 'bg-pink-100 text-pink-500 hover:bg-pink-200'
            }`}
            title={bookmarked ? "Tersimpan di favorit" : "Simpan bait puitis"}
          >
            <Bookmark className="w-4 h-4" fill={bookmarked ? "currentColor" : "none"} />
          </button>
        </div>

        {/* Header Title */}
        <div className="mb-8 text-center sm:text-left">
          <span className="text-xs font-bold text-pink-500 uppercase tracking-widest">
            {currentItem.type === 'Literature' ? '📖 Sastra Modern & Keheningan' : '🌷 Puisi Estetik Senja'}
          </span>
          <h3 className="text-2xl sm:text-3xl font-serif-title font-bold text-pink-900 mt-1">
            {currentItem.title}
          </h3>
          <p className="text-xs sm:text-sm text-pink-700 italic mt-1 font-handwriting text-lg">
            "{currentItem.subtitle}"
          </p>
        </div>

        {/* Stanzas Display */}
        <div className="space-y-6 text-pink-950 text-sm sm:text-base leading-relaxed">
          {currentItem.stanzas.map((stanza, idx) => (
            <div
              key={idx}
              className="p-4 sm:p-5 rounded-2xl bg-white/50 backdrop-blur-sm border border-pink-200/50 hover:bg-white/80 transition-all group"
            >
              <div className="flex items-start gap-3">
                <span className="text-xs font-bold text-pink-400 group-hover:text-pink-600 transition">
                  0{idx + 1}.
                </span>
                <p className="whitespace-pre-line font-serif-title font-medium leading-loose text-pink-900">
                  {stanza}
                </p>
              </div>
            </div>
          ))}
        </div>

        {/* Note Footer */}
        <div className="mt-8 pt-6 border-t border-pink-200/60 flex flex-col sm:flex-row items-center justify-between gap-3 text-xs text-pink-700">
          <div className="flex items-center gap-2">
            <Sparkles className="w-4 h-4 text-amber-400 animate-spin" />
            <span>{currentItem.note}</span>
          </div>
          <div className="flex items-center gap-1.5 text-pink-500 font-bold">
            <Heart className="w-3.5 h-3.5 fill-pink-400" />
            <span>Written with sincerity</span>
          </div>
        </div>
      </div>
    </div>
  );
};
