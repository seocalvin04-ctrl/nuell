import React, { useState, useEffect, useRef } from 'react';
import { Volume2, VolumeX, Play, Pause, Music, Disc } from 'lucide-react';

interface AudioPlayerProps {
  src: string;
  autoPlayPrompt?: boolean;
}

export const AudioPlayer: React.FC<AudioPlayerProps> = ({ src, autoPlayPrompt = true }) => {
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const [isPlaying, setIsPlaying] = useState<boolean>(false);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [volume, setVolume] = useState<number>(0.8);
  const [currentTime, setCurrentTime] = useState<number>(0);
  const [duration, setDuration] = useState<number>(0);
  const [showPrompt, setShowPrompt] = useState<boolean>(autoPlayPrompt);
  const [isExpanded, setIsExpanded] = useState<boolean>(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return;

    audio.volume = volume;

    const handleTimeUpdate = () => setCurrentTime(audio.currentTime);
    const handleLoadedMetadata = () => setDuration(audio.duration || 0);
    const handleEnded = () => {
      audio.currentTime = 0;
      audio.play().catch(() => {});
    };

    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('ended', handleEnded);

    return () => {
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('ended', handleEnded);
    };
  }, []);

  const togglePlay = () => {
    const audio = audioRef.current;
    if (!audio) return;

    if (isPlaying) {
      audio.pause();
      setIsPlaying(false);
    } else {
      audio.play().then(() => {
        setIsPlaying(true);
        setShowPrompt(false);
      }).catch((err) => {
        console.warn("Audio play prevented:", err);
      });
    }
  };

  const handlePromptChoice = (accept: boolean) => {
    setShowPrompt(false);
    if (accept) {
      const audio = audioRef.current;
      if (audio) {
        audio.play().then(() => {
          setIsPlaying(true);
        }).catch((err) => {
          console.warn("Autoplay block:", err);
        });
      }
    }
  };

  const toggleMute = () => {
    const audio = audioRef.current;
    if (!audio) return;
    audio.muted = !isMuted;
    setIsMuted(!isMuted);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newVol = parseFloat(e.target.value);
    setVolume(newVol);
    if (audioRef.current) {
      audioRef.current.volume = newVol;
      setIsMuted(newVol === 0);
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    const newTime = parseFloat(e.target.value);
    setCurrentTime(newTime);
    if (audioRef.current) {
      audioRef.current.currentTime = newTime;
    }
  };

  const formatTime = (secs: number) => {
    if (isNaN(secs)) return "0:00";
    const mins = Math.floor(secs / 60);
    const remainingSecs = Math.floor(secs % 60);
    return `${mins}:${remainingSecs < 10 ? '0' : ''}${remainingSecs}`;
  };

  return (
    <>
      {/* Hidden Audio Element */}
      <audio ref={audioRef} src={src} preload="metadata" />

      {/* Music Permission Modal Prompt */}
      {showPrompt && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/40 backdrop-blur-sm animate-fade-in">
          <div className="relative max-w-sm w-full bg-white/95 backdrop-blur-md rounded-3xl p-6 border border-pink-200 shadow-2xl text-center transform transition-all animate-float-bounce">
            <div className="w-16 h-16 mx-auto mb-4 rounded-full bg-pink-100 flex items-center justify-center border-2 border-pink-300 text-pink-500 shadow-inner">
              <Disc className="w-9 h-9 animate-spin" style={{ animationDuration: '8s' }} />
            </div>
            <h3 className="text-xl font-bold font-serif-title text-pink-900 mb-2">
              Putar Musik Latar? 🎵
            </h3>
            <p className="text-xs text-pink-700 leading-relaxed mb-6">
              "HIVI! - Pelangi" siap menemani perjalanan menjelajah kejutan manis ini agar terasa semakin sinematik & hangat. 🌸✨
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => handlePromptChoice(false)}
                className="flex-1 py-2.5 rounded-full bg-pink-100 hover:bg-pink-200 text-pink-700 text-xs font-semibold transition cursor-pointer"
              >
                Nanti Saja
              </button>
              <button
                onClick={() => handlePromptChoice(true)}
                className="flex-1 py-2.5 rounded-full bg-gradient-to-r from-pink-500 to-rose-400 text-white text-xs font-bold shadow-md hover:shadow-lg transition transform active:scale-95 cursor-pointer"
              >
                Ya, Putar! ✨
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Floating Glassmorphism Player Widget */}
      <div className="fixed top-4 right-4 z-40 select-none">
        <div className="relative glass-card rounded-2xl p-2.5 shadow-xl border border-white/80 transition-all duration-300">
          <div className="flex items-center gap-3">
            {/* Spinning Disc / Play Button */}
            <button
              onClick={togglePlay}
              className={`relative flex items-center justify-center w-11 h-11 rounded-full bg-gradient-to-tr from-pink-500 to-rose-400 text-white shadow-md transition transform active:scale-95 cursor-pointer ${
                isPlaying ? 'ring-2 ring-pink-300 ring-offset-1' : ''
              }`}
              title={isPlaying ? "Jeda Musik" : "Putar Musik"}
            >
              <Disc className={`w-6 h-6 ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '4s' }} />
              <div className="absolute inset-0 flex items-center justify-center">
                {isPlaying ? <Pause className="w-4 h-4 text-white fill-white" /> : <Play className="w-4 h-4 text-white fill-white ml-0.5" />}
              </div>
            </button>

            {/* Song Info & Controls */}
            <div className="flex flex-col cursor-pointer" onClick={() => setIsExpanded(!isExpanded)}>
              <div className="flex items-center gap-1.5">
                <span className="text-xs font-bold text-pink-900 truncate max-w-[130px] sm:max-w-[160px]">
                  HIVI! - Pelangi 🌈
                </span>
                {isPlaying && (
                  <span className="flex items-center gap-0.5 h-3">
                    <span className="w-0.5 bg-pink-500 rounded-full sound-bar" style={{ animationDelay: '0s' }}></span>
                    <span className="w-0.5 bg-pink-500 rounded-full sound-bar" style={{ animationDelay: '0.3s' }}></span>
                    <span className="w-0.5 bg-pink-500 rounded-full sound-bar" style={{ animationDelay: '0.6s' }}></span>
                  </span>
                )}
              </div>
              <span className="text-[10px] text-pink-600">
                {formatTime(currentTime)} / {formatTime(duration)}
              </span>
            </div>

            {/* Mute Button */}
            <button
              onClick={toggleMute}
              className="p-1.5 text-pink-600 hover:text-pink-900 transition"
              title={isMuted ? "Unmute" : "Mute"}
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>
          </div>

          {/* Expanded Player Slider Controls */}
          {isExpanded && (
            <div className="mt-3 pt-3 border-t border-pink-200/60 flex flex-col gap-2 animate-fade-in text-xs">
              {/* Audio Seek Bar */}
              <div className="flex items-center gap-2">
                <input
                  type="range"
                  min="0"
                  max={duration || 100}
                  value={currentTime}
                  onChange={handleSeek}
                  className="w-full h-1.5 bg-pink-200 rounded-lg appearance-none cursor-pointer accent-pink-500"
                />
              </div>

              {/* Volume Slider */}
              <div className="flex items-center justify-between text-[11px] text-pink-700">
                <span className="flex items-center gap-1">
                  <Music className="w-3 h-3 text-pink-500" /> Volume
                </span>
                <input
                  type="range"
                  min="0"
                  max="1"
                  step="0.05"
                  value={volume}
                  onChange={handleVolumeChange}
                  className="w-20 h-1.5 bg-pink-200 rounded-lg appearance-none cursor-pointer accent-pink-500"
                />
              </div>
            </div>
          )}
        </div>
      </div>
    </>
  );
};
