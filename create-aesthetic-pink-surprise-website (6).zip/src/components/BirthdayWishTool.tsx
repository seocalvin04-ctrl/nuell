import React, { useState } from 'react';
import { Cake, Sparkles, Clock, Award } from 'lucide-react';
import confetti from 'canvas-confetti';

export const BirthdayWishTool: React.FC = () => {
  const [birthDate, setBirthDate] = useState<string>('');
  const [stats, setStats] = useState<{ days: number; hours: number; wish: string } | null>(null);

  const calculateStats = (e: React.FormEvent) => {
    e.preventDefault();
    if (!birthDate) return;

    const selected = new Date(birthDate);
    const now = new Date();
    const diffTime = Math.abs(now.getTime() - selected.getTime());
    const days = Math.floor(diffTime / (1000 * 60 * 60 * 24));
    const hours = days * 24;

    const wishes = [
      "Sudah sebanyak ini hari kamu menebar kebaikan & keceriaan di bumi! 🌍✨ Kamu luar biasa!",
      "Setiap detiknya adalah anugerah indah. Tetaplah menjadi pribadi yang lembut dan menyenangkan! 🌸",
      "Kamu telah melewati ribuan hari dengan luar biasa. Teruslah mengejar impianmu! 🌈⭐"
    ];

    const randomWish = wishes[Math.floor(Math.random() * wishes.length)];
    setStats({ days, hours, wish: randomWish });

    // Grand Fireworks Burst
    const duration = 2 * 1000;
    const end = Date.now() + duration;

    (function frame() {
      confetti({
        particleCount: 5,
        angle: 60,
        spread: 55,
        origin: { x: 0 },
        colors: ['#f472b6', '#fb7185', '#fde047']
      });
      confetti({
        particleCount: 5,
        angle: 120,
        spread: 55,
        origin: { x: 1 },
        colors: ['#e879f9', '#38bdf8', '#ffd1dc']
      });

      if (Date.now() < end) {
        requestAnimationFrame(frame);
      }
    })();
  };

  return (
    <div className="relative my-16 max-w-3xl mx-auto px-4">
      <div className="glass-card rounded-3xl p-8 border border-white/90 shadow-2xl transition-all">
        <div className="text-center mb-6">
          <div className="inline-flex items-center gap-2 px-4 py-1 rounded-full bg-pink-100 text-pink-700 text-xs font-bold uppercase tracking-wider mb-2">
            <Cake className="w-3.5 h-3.5 text-pink-500 animate-bounce" />
            <span>Kalkulator Hari Istimewa & Harapan 🎂</span>
          </div>
          <h3 className="text-2xl font-serif-title font-bold text-pink-900">
            Jejak Waktu & Kehadiran Berharga
          </h3>
          <p className="text-xs text-pink-700 mt-1">
            Pilih tanggal lahir atau hari spesialmu untuk melihat berapa lama kamu telah menyinari dunia!
          </p>
        </div>

        <form onSubmit={calculateStats} className="flex flex-col sm:flex-row items-center justify-center gap-3 mb-6">
          <div className="relative w-full sm:w-auto">
            <input
              type="date"
              value={birthDate}
              onChange={(e) => setBirthDate(e.target.value)}
              className="w-full sm:w-64 px-4 py-2.5 rounded-full bg-white/90 border border-pink-300 text-xs font-semibold text-pink-900 focus:outline-none focus:ring-2 focus:ring-pink-400 shadow-sm"
              required
            />
          </div>
          <button
            type="submit"
            className="w-full sm:w-auto px-6 py-2.5 rounded-full bg-gradient-to-r from-pink-500 to-rose-400 text-white text-xs font-bold shadow-md hover:shadow-lg transition transform active:scale-95 cursor-pointer flex items-center justify-center gap-2"
          >
            <Sparkles className="w-4 h-4 text-amber-300" />
            <span>Hitung Keajaiban Waktu ✨</span>
          </button>
        </form>

        {stats && (
          <div className="mt-6 p-6 rounded-2xl bg-gradient-to-br from-pink-50 to-rose-100 border border-pink-200 text-center animate-fade-in shadow-inner">
            <div className="grid grid-cols-2 gap-4 mb-4">
              <div className="p-4 rounded-xl bg-white/80 border border-pink-200 shadow-sm flex flex-col items-center">
                <Clock className="w-6 h-6 text-pink-500 mb-1" />
                <span className="text-2xl font-extrabold text-pink-900 font-rounded">
                  {stats.days.toLocaleString()}
                </span>
                <span className="text-[11px] font-bold text-pink-700 uppercase">Hari Berharga</span>
              </div>
              <div className="p-4 rounded-xl bg-white/80 border border-pink-200 shadow-sm flex flex-col items-center">
                <Award className="w-6 h-6 text-amber-500 mb-1" />
                <span className="text-2xl font-extrabold text-pink-900 font-rounded">
                  {stats.hours.toLocaleString()}
                </span>
                <span className="text-[11px] font-bold text-pink-700 uppercase">Jam Menyinari Dunia</span>
              </div>
            </div>

            <p className="text-sm font-serif-title font-medium text-pink-900 leading-relaxed font-handwriting text-xl">
              "{stats.wish}"
            </p>
          </div>
        )}
      </div>
    </div>
  );
};
