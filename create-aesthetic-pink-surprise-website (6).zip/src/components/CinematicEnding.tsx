import React from 'react';
import { Heart, Sparkles, RefreshCw } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CinematicEndingProps {
  onReplay: () => void;
}

export const CinematicEnding: React.FC<CinematicEndingProps> = ({ onReplay }) => {
  const triggerEndingFireworks = () => {
    confetti({
      particleCount: 80,
      spread: 100,
      origin: { y: 0.6 },
      colors: ['#f472b6', '#fb7185', '#fce7f3', '#ffd1dc', '#fde047']
    });
  };

  return (
    <div className="relative my-20 max-w-3xl mx-auto px-4 text-center">
      {/* Cinematic Frame */}
      <div className="relative glass-card-dark rounded-3xl p-8 sm:p-12 border border-pink-300/30 shadow-2xl overflow-hidden text-pink-100">
        {/* Soft Pink Aurora Background Overlay */}
        <div className="absolute inset-0 bg-gradient-to-t from-pink-900/80 via-purple-900/50 to-pink-950/90 pointer-events-none" />

        <div className="relative z-10 flex flex-col items-center">
          {/* Top Floating Glow Icon */}
          <div className="mb-6 p-4 rounded-full bg-pink-500/20 border border-pink-400/40 shadow-inner animate-float-slow">
            <Heart className="w-10 h-10 text-pink-300 fill-pink-400/80 animate-pulse" />
          </div>

          <p className="text-xs uppercase tracking-widest text-pink-300 font-bold mb-2">
            Penutup Perjalanan Manis 🌸
          </p>

          <h2 className="text-2xl sm:text-4xl font-serif-title font-bold text-white leading-snug mb-6 drop-shadow">
            Terima kasih sudah meluangkan waktu untuk membuka halaman kecil ini. 🤍
          </h2>

          <p className="text-sm sm:text-base text-pink-200 leading-relaxed max-w-xl mx-auto mb-8 font-serif-title">
            "Semoga setiap langkahmu dipenuhi cerita yang baik, setiap harimu membawa alasan untuk tersenyum, dan setiap pertemuan baru menjadi awal dari sesuatu yang indah."
          </p>

          {/* Final Original Poem */}
          <div className="p-6 rounded-2xl bg-white/10 backdrop-blur-md border border-pink-300/20 max-w-md w-full mb-8 text-pink-100 font-handwriting text-2xl leading-relaxed">
            "Di ujung petang pelangi terurai,<br />
            Menitip damai di dalam dada,<br />
            Semoga bahagiamu tak pernah usai,<br />
            Disertai senyuman yang paling indah." 🌸✨
          </div>

          {/* Action Buttons */}
          <div className="flex flex-col sm:flex-row items-center gap-4">
            <button
              onClick={triggerEndingFireworks}
              className="px-6 py-3 rounded-full bg-gradient-to-r from-pink-500 to-rose-400 text-white text-xs sm:text-sm font-bold shadow-lg hover:shadow-pink-500/40 transition transform active:scale-95 cursor-pointer flex items-center gap-2"
            >
              <Sparkles className="w-4 h-4 text-yellow-200" />
              <span>Nyalakan Bunga Api Cinta ✨</span>
            </button>

            <button
              onClick={onReplay}
              className="px-6 py-3 rounded-full bg-white/20 hover:bg-white/30 text-white border border-pink-300/40 text-xs sm:text-sm font-bold shadow-md transition transform active:scale-95 cursor-pointer flex items-center gap-2"
            >
              <RefreshCw className="w-4 h-4" />
              <span>Putar Ulang Kejutan 🕊️</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
