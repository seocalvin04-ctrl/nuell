import React, { useEffect, useRef } from 'react';

interface BackgroundProps {
  theme?: 'soft-pink' | 'aurora-night' | 'dreamy';
}

export const BackgroundEffects: React.FC<BackgroundProps> = ({ theme = 'soft-pink' }) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    // Particle instances
    interface Particle {
      x: number;
      y: number;
      radius: number;
      color: string;
      vx: number;
      vy: number;
      alpha: number;
      pulseSpeed: number;
      type: 'dust' | 'heart' | 'star' | 'firefly';
    }

    const particles: Particle[] = [];
    const particleCount = Math.min(80, Math.floor((width * height) / 15000));

    const colors = [
      'rgba(244, 114, 182, ', // pink-400
      'rgba(251, 207, 232, ', // pink-200
      'rgba(232, 121, 249, ', // fuchsia-400
      'rgba(253, 224, 71, ',  // yellow-300
      'rgba(255, 255, 255, '   // white
    ];

    for (let i = 0; i < particleCount; i++) {
      const typeRand = Math.random();
      const type = typeRand > 0.7 ? 'heart' : typeRand > 0.4 ? 'star' : typeRand > 0.2 ? 'firefly' : 'dust';
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        radius: Math.random() * (type === 'heart' ? 6 : 3) + 1.5,
        color: colors[Math.floor(Math.random() * colors.length)],
        vx: (Math.random() - 0.5) * 0.6,
        vy: -Math.random() * 0.8 - 0.2,
        alpha: Math.random() * 0.7 + 0.3,
        pulseSpeed: Math.random() * 0.03 + 0.008,
        type
      });
    }

    // Shooting stars
    interface ShootingStar {
      x: number;
      y: number;
      length: number;
      speed: number;
      alpha: number;
      angle: number;
    }
    const shootingStars: ShootingStar[] = [];

    const createShootingStar = () => {
      if (Math.random() < 0.03 && shootingStars.length < 3) {
        shootingStars.push({
          x: Math.random() * width,
          y: Math.random() * (height * 0.5),
          length: Math.random() * 80 + 40,
          speed: Math.random() * 10 + 6,
          alpha: 1,
          angle: Math.PI / 4
        });
      }
    };

    // Mouse tracking for reactive light glow
    const mouse = { x: width / 2, y: height / 2, targetX: width / 2, targetY: height / 2 };
    const handleMouseMove = (e: MouseEvent) => {
      mouse.targetX = e.clientX;
      mouse.targetY = e.clientY;
    };
    window.addEventListener('mousemove', handleMouseMove);

    const drawHeart = (x: number, y: number, size: number, colorAlpha: string) => {
      ctx.save();
      ctx.translate(x, y);
      ctx.fillStyle = colorAlpha;
      ctx.beginPath();
      const topCurveHeight = size * 0.3;
      ctx.moveTo(0, topCurveHeight);
      ctx.bezierCurveTo(0, 0, -size / 2, 0, -size / 2, topCurveHeight);
      ctx.bezierCurveTo(-size / 2, (size + topCurveHeight) / 2, 0, size, 0, size);
      ctx.bezierCurveTo(0, size, size / 2, (size + topCurveHeight) / 2, size / 2, topCurveHeight);
      ctx.bezierCurveTo(size / 2, 0, 0, 0, 0, topCurveHeight);
      ctx.closePath();
      ctx.fill();
      ctx.restore();
    };

    let frame = 0;
    const render = () => {
      frame++;
      ctx.clearRect(0, 0, width, height);

      // Smooth mouse glow position
      mouse.x += (mouse.targetX - mouse.x) * 0.05;
      mouse.y += (mouse.targetY - mouse.y) * 0.05;

      // Mouse reactive light radial glow
      const radialGlow = ctx.createRadialGradient(
        mouse.x, mouse.y, 10,
        mouse.x, mouse.y, 250
      );
      radialGlow.addColorStop(0, 'rgba(253, 242, 248, 0.25)');
      radialGlow.addColorStop(0.5, 'rgba(244, 114, 182, 0.08)');
      radialGlow.addColorStop(1, 'rgba(255, 255, 255, 0)');
      ctx.fillStyle = radialGlow;
      ctx.fillRect(0, 0, width, height);

      // Shooting stars logic
      createShootingStar();
      for (let i = shootingStars.length - 1; i >= 0; i--) {
        const star = shootingStars[i];
        star.x += Math.cos(star.angle) * star.speed;
        star.y += Math.sin(star.angle) * star.speed;
        star.alpha -= 0.015;

        if (star.alpha <= 0 || star.x > width || star.y > height) {
          shootingStars.splice(i, 1);
          continue;
        }

        const grad = ctx.createLinearGradient(
          star.x, star.y,
          star.x - Math.cos(star.angle) * star.length,
          star.y - Math.sin(star.angle) * star.length
        );
        grad.addColorStop(0, `rgba(255, 255, 255, ${star.alpha})`);
        grad.addColorStop(1, `rgba(244, 114, 182, 0)`);

        ctx.strokeStyle = grad;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.moveTo(star.x, star.y);
        ctx.lineTo(
          star.x - Math.cos(star.angle) * star.length,
          star.y - Math.sin(star.angle) * star.length
        );
        ctx.stroke();
      }

      // Draw particles
      particles.forEach((p) => {
        p.x += p.vx;
        p.y += p.vy;

        p.alpha += Math.sin(frame * p.pulseSpeed) * 0.01;
        const currentAlpha = Math.max(0.1, Math.min(0.9, p.alpha));

        if (p.y < -20) {
          p.y = height + 10;
          p.x = Math.random() * width;
        }
        if (p.x < -20) p.x = width + 10;
        if (p.x > width + 20) p.x = -10;

        if (p.type === 'heart') {
          drawHeart(p.x, p.y, p.radius * 2, `${p.color}${currentAlpha})`);
        } else if (p.type === 'star') {
          ctx.save();
          ctx.translate(p.x, p.y);
          ctx.fillStyle = `${p.color}${currentAlpha})`;
          ctx.beginPath();
          ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
          ctx.fill();
          // Star cross glow
          ctx.strokeStyle = `${p.color}${currentAlpha * 0.5})`;
          ctx.lineWidth = 1;
          ctx.beginPath();
          ctx.moveTo(-p.radius * 2, 0); ctx.lineTo(p.radius * 2, 0);
          ctx.moveTo(0, -p.radius * 2); ctx.lineTo(0, p.radius * 2);
          ctx.stroke();
          ctx.restore();
        } else {
          // Dust & Fireflies
          ctx.fillStyle = `${p.color}${currentAlpha})`;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
          ctx.fill();
        }
      });

      animationFrameId = requestAnimationFrame(render);
    };

    render();

    return () => {
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      cancelAnimationFrame(animationFrameId);
    };
  }, [theme]);

  return (
    <div className="fixed inset-0 pointer-events-none z-0 overflow-hidden">
      {/* Animated Aurora Base */}
      <div className={`absolute inset-0 transition-opacity duration-1000 ${
        theme === 'aurora-night' ? 'animated-aurora-dark opacity-90' : 'animated-aurora-bg opacity-70'
      }`} />

      {/* Floating Bokeh Blurs */}
      <div className="absolute top-10 left-10 w-96 h-96 bg-pink-300/30 rounded-full blur-3xl animate-pulse" />
      <div className="absolute bottom-20 right-10 w-96 h-96 bg-fuchsia-300/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '2s' }} />
      <div className="absolute top-1/2 left-1/3 w-80 h-80 bg-rose-200/40 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '4s' }} />

      {/* Dynamic Canvas */}
      <canvas ref={canvasRef} className="absolute inset-0 w-full h-full" />
    </div>
  );
};
