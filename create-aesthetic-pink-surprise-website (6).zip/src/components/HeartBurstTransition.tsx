import React, { useEffect } from 'react';
import confetti from 'canvas-confetti';

interface HeartBurstProps {
  isActive: boolean;
  onAnimationEnd: () => void;
}

export const HeartBurstTransition: React.FC<HeartBurstProps> = ({ isActive, onAnimationEnd }) => {
  useEffect(() => {
    if (!isActive) return;

    // Trigger fireworks and confetti explosion
    const count = 200;
    const defaults = {
      origin: { y: 0.6 }
    };

    function fire(particleRatio: number, opts: confetti.Options) {
      confetti({
        ...defaults,
        ...opts,
        particleCount: Math.floor(count * particleRatio)
      });
    }

    // Firecrackers / Sparkles sequence
    fire(0.25, {
      spread: 26,
      startVelocity: 55,
      colors: ['#f472b6', '#fb7185', '#fce7f3', '#ffd1dc', '#fde047']
    });
    fire(0.2, {
      spread: 60,
      colors: ['#ec4899', '#db2777', '#ffffff', '#f472b6']
    });
    fire(0.35, {
      spread: 100,
      decay: 0.91,
      scalar: 0.8
    });
    fire(0.1, {
      spread: 120,
      startVelocity: 25,
      decay: 0.92,
      colors: ['#f59e0b', '#fce7f3', '#f472b6']
    });

    const timer = setTimeout(() => {
      onAnimationEnd();
    }, 1100);

    return () => clearTimeout(timer);
  }, [isActive, onAnimationEnd]);

  if (!isActive) return null;

  return (
    <div className="fixed inset-0 z-50 pointer-events-none flex items-center justify-center overflow-hidden">
      {/* Expanding Soft Pink Radial Heart Curtain */}
      <div className="heart-screen-cover w-[250vw] h-[250vw] rounded-full bg-gradient-to-tr from-pink-400 via-rose-300 to-pink-200 shadow-2xl flex items-center justify-center">
        <div className="text-white text-center flex flex-col items-center animate-pulse">
          <svg className="w-32 h-32 text-white fill-white animate-bounce drop-shadow-2xl" viewBox="0 0 24 24">
            <path d="M12 21.35l-1.45-1.32C5.4 15.36 2 12.28 2 8.5 2 5.42 4.42 3 7.5 3c1.74 0 3.41.81 4.5 2.09C13.09 3.81 14.76 3 16.5 3 19.58 3 22 5.42 22 8.5c0 3.78-3.4 6.86-8.55 11.54L12 21.35z"/>
          </svg>
          <span className="text-2xl font-serif-title font-bold text-white tracking-widest mt-2 drop-shadow">
            ✨ Surprise For You ✨
          </span>
        </div>
      </div>
    </div>
  );
};
