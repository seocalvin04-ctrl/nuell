import React, { useState, useEffect } from 'react';
import { Quote as QuoteIcon, Sparkles, RefreshCw, ChevronLeft, ChevronRight, Heart } from 'lucide-react';
import { QUOTES_LIST } from '../data/content';
import { Quote } from '../types';

export const QuoteCarousel: React.FC = () => {
  const [selectedCategory, setSelectedCategory] = useState<string>('Semua');
  const [currentIndex, setCurrentIndex] = useState<number>(0);
  const [isAutoPlay, setIsAutoPlay] = useState<boolean>(true);

  const categories = ['Semua', 'Harapan', 'Semangat', 'Kebaikan', 'Senyuman', 'Mimpi', 'Ketenangan'];

  const filteredQuotes = selectedCategory === 'Semua'
    ? QUOTES_LIST
    : QUOTES_LIST.filter(q => q.category === selectedCategory);

  useEffect(() => {
    if (!isAutoPlay || filteredQuotes.length === 0) return;
    const interval = setInterval(() => {
      setCurrentIndex((prev) => (prev + 1) % filteredQuotes.length);
    }, 5000);
    return () => clearInterval(interval);
  }, [isAutoPlay, filteredQuotes]);

  const handleNext = () => {
    setIsAutoPlay(false);
    setCurrentIndex((prev) => (prev + 1) % filteredQuotes.length);
  };

  const handlePrev = () => {
    setIsAutoPlay(false);
    setCurrentIndex((prev) => (prev - 1 + filteredQuotes.length) % filteredQuotes.length);
  };

  const handleRandom = () => {
    setIsAutoPlay(false);
    const rand = Math.floor(Math.random() * filteredQuotes.length);
    setCurrentIndex(rand);
  };

  const currentQuote: Quote = filteredQuotes[currentIndex] || QUOTES_LIST[0];

  return (
    <div className="relative my-16 max-w-4xl mx-auto px-4">
      {/* Header */}
      <div className="text-center mb-8">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/80 border border-pink-300 shadow-sm text-pink-700 text-xs font-bold uppercase tracking-wider mb-3">
          <QuoteIcon className="w-3.5 h-3.5 text-pink-500" />
          <span>Kumpulan 50+ Quote Hangat 🌸</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-serif-title font-bold text-pink-900 tracking-tight">
          Penyemangat & Pengingat Kebaikan
        </h2>
        <p className="mt-2 text-sm text-pink-700 max-w-md mx-auto">
          Setiap kutipan menyimpan energi positif untuk menemani harimu.
        </p>
      </div>

      {/* Filter Category Pills */}
      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => {
              setSelectedCategory(cat);
              setCurrentIndex(0);
            }}
            className={`px-4 py-1.5 rounded-full text-xs font-bold transition-all shadow-sm cursor-pointer ${
              selectedCategory === cat
                ? 'bg-pink-500 text-white shadow-md shadow-pink-300/50'
                : 'bg-white/80 hover:bg-white text-pink-700 border border-pink-200'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Main Glass Quote Box */}
      <div className="relative glass-card rounded-3xl p-8 sm:p-12 border border-white/90 shadow-2xl transition-all min-h-[220px] flex flex-col justify-between">
        {/* Top Icon & Category Tag */}
        <div className="flex items-center justify-between mb-4">
          <span className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-pink-100 text-pink-700 text-xs font-extrabold uppercase">
            <Sparkles className="w-3 h-3 text-amber-400" />
            <span>Kategori: {currentQuote.category}</span>
          </span>

          <button
            onClick={handleRandom}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-full bg-white/90 hover:bg-white text-pink-600 border border-pink-300 text-xs font-bold shadow-sm transition transform active:scale-95 cursor-pointer"
            title="Kutipan Acak"
          >
            <RefreshCw className="w-3.5 h-3.5 text-pink-500" />
            <span>Acak Quote</span>
          </button>
        </div>

        {/* Quote Content */}
        <div className="my-4 text-center">
          <QuoteIcon className="w-8 h-8 text-pink-300/60 mx-auto mb-2 rotate-180" />
          <p className="text-lg sm:text-2xl font-serif-title font-medium text-pink-950 leading-relaxed drop-shadow-sm px-4">
            "{currentQuote.text}"
          </p>
        </div>

        {/* Navigation & Counter */}
        <div className="flex items-center justify-between pt-6 border-t border-pink-200/60">
          <button
            onClick={handlePrev}
            className="p-2.5 rounded-full bg-white/80 hover:bg-white text-pink-700 shadow-md transition transform active:scale-95 cursor-pointer"
          >
            <ChevronLeft className="w-5 h-5" />
          </button>

          <div className="flex items-center gap-2">
            <span className="text-xs font-bold text-pink-800">
              {currentIndex + 1} / {filteredQuotes.length}
            </span>
            <Heart className="w-3.5 h-3.5 text-pink-500 fill-pink-400" />
          </div>

          <button
            onClick={handleNext}
            className="p-2.5 rounded-full bg-white/80 hover:bg-white text-pink-700 shadow-md transition transform active:scale-95 cursor-pointer"
          >
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>
    </div>
  );
};
