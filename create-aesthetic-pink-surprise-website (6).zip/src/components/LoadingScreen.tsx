import React, { useState, useEffect } from 'react';
import { Sparkles, Heart, Gift } from 'lucide-react';

interface LoadingScreenProps {
  onComplete: () => void;
}

export const LoadingScreen: React.FC<LoadingScreenProps> = ({ onComplete }) => {
  const [progress, setProgress] = useState<number>(0);
  const [loadingText, setLoadingText] = useState<string>("Menyiapkan kehangatan...");

  const loadingMessages = [
    "Menyiapkan kehangatan...",
    "Membuat kelinci & beruang bersiap...",
    "Menyusun bait-bait puisi indah...",
    "Mewarnai langit dengan soft pink...",
    "Menyetel alunan musik pelangi...",
    "Hampir siap! Kejutan spesial untukmu! ✨"
  ];

  useEffect(() => {
    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(timer);
          setTimeout(() => {
            onComplete();
          }, 400);
          return 100;
        }
        const next = prev + Math.floor(Math.random() * 12) + 5;
        const msgIdx = Math.min(
          loadingMessages.length - 1,
          Math.floor((next / 100) * loadingMessages.length)
        );
        setLoadingText(loadingMessages[msgIdx]);
        return Math.min(100, next);
      });
    }, 150);

    return () => clearInterval(timer);
  }, [onComplete]);

  return (
    <div className="fixed inset-0 z-50 flex flex-col items-center justify-center bg-gradient-to-br from-pink-100 via-rose-100 to-pink-200 text-pink-900 p-6 overflow-hidden select-none">
      {/* Background Soft Glow Bulbs */}
      <div className="absolute w-80 h-80 bg-pink-300/40 rounded-full blur-3xl animate-pulse" />
      <div className="absolute w-64 h-64 bg-fuchsia-200/50 rounded-full blur-2xl animate-pulse" style={{ animationDelay: '1s' }} />

      <div className="relative z-10 flex flex-col items-center max-w-sm w-full text-center">
        {/* Animated Cute Characters Mascot */}
        <div className="relative mb-6">
          <div className="absolute -inset-4 rounded-full bg-pink-300/30 blur-xl animate-pulse" />
          
          <div className="flex items-center justify-center gap-2">
            {/* Soft Pink Teddy Bear */}
            <div className="animate-float-bounce">
              <svg className="w-20 h-20 drop-shadow-md" viewBox="0 0 120 120" fill="none">
                <circle cx="35" cy="35" r="16" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
                <circle cx="35" cy="35" r="9" fill="#fce7f3" />
                <circle cx="85" cy="35" r="16" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
                <circle cx="85" cy="35" r="9" fill="#fce7f3" />
                <circle cx="60" cy="55" r="34" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
                <ellipse cx="60" cy="62" rx="14" ry="10" fill="#fff" stroke="#f9a8d4" strokeWidth="2" />
                <ellipse cx="60" cy="58" rx="5" ry="3.5" fill="#db2777" />
                <path d="M 56 62 Q 60 66 64 62" stroke="#db2777" strokeWidth="2" fill="none" />
                <circle cx="48" cy="50" r="3.5" fill="#4a044e" />
                <circle cx="72" cy="50" r="3.5" fill="#4a044e" />
                <ellipse cx="40" cy="58" rx="5" ry="3" fill="#f472b6" opacity="0.6" />
                <ellipse cx="80" cy="58" rx="5" ry="3" fill="#f472b6" opacity="0.6" />
              </svg>
            </div>

            {/* Sparkle Heart Center */}
            <div className="flex flex-col items-center animate-pulse">
              <Heart className="w-8 h-8 text-pink-500 fill-pink-400 animate-ping" />
            </div>

            {/* Soft Pink Bunny */}
            <div className="animate-float-slow">
              <svg className="w-20 h-20 drop-shadow-md" viewBox="0 0 120 120" fill="none">
                <path d="M 40 45 C 30 10 40 0 48 10 C 52 25 45 40 45 45 Z" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
                <path d="M 80 45 C 90 10 80 0 72 10 C 68 25 75 40 75 45 Z" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
                <circle cx="60" cy="60" r="32" fill="#fff0f5" stroke="#f472b6" strokeWidth="3" />
                <ellipse cx="48" cy="56" rx="3.5" ry="4.5" fill="#4a044e" />
                <ellipse cx="72" cy="56" rx="3.5" ry="4.5" fill="#4a044e" />
                <path d="M 58 63 L 62 63 L 60 66 Z" fill="#ec4899" />
                <circle cx="40" cy="62" r="5" fill="#f472b6" opacity="0.6" />
                <circle cx="80" cy="62" r="5" fill="#f472b6" opacity="0.6" />
              </svg>
            </div>
          </div>
        </div>

        {/* Title & Brand */}
        <div className="flex items-center gap-2 mb-2 text-pink-600 font-semibold tracking-wider text-xs uppercase">
          <Sparkles className="w-4 h-4 animate-spin text-pink-500" />
          <span>A Little Surprise Just For You</span>
          <Sparkles className="w-4 h-4 animate-spin text-pink-500" />
        </div>

        <h2 className="text-2xl font-bold font-serif-title text-pink-900 mb-4">
          Aesthetic Soft Surprise 🌸
        </h2>

        {/* Circular Progress & Percentage */}
        <div className="relative flex items-center justify-center my-3">
          <svg className="w-28 h-28 transform -rotate-90">
            <circle
              cx="56"
              cy="56"
              r="48"
              className="text-pink-200"
              strokeWidth="8"
              stroke="currentColor"
              fill="transparent"
            />
            <circle
              cx="56"
              cy="56"
              r="48"
              className="text-pink-500 transition-all duration-300 ease-out"
              strokeWidth="8"
              strokeDasharray={301.59}
              strokeDashoffset={301.59 - (301.59 * progress) / 100}
              strokeLinecap="round"
              stroke="currentColor"
              fill="transparent"
            />
          </svg>
          <div className="absolute flex flex-col items-center">
            <span className="text-2xl font-extrabold text-pink-800 font-rounded">
              {progress}%
            </span>
          </div>
        </div>

        {/* Loading Message */}
        <p className="text-sm font-medium text-pink-700 min-h-[24px] transition-opacity duration-300">
          {loadingText}
        </p>

        {/* Instant Skip Button if user doesn't want to wait */}
        <button
          onClick={onComplete}
          className="mt-6 flex items-center gap-2 px-5 py-2.5 rounded-full bg-white/80 hover:bg-white text-pink-700 text-xs font-bold border border-pink-300 shadow-md hover:shadow-lg transition-all transform active:scale-95 cursor-pointer"
        >
          <Gift className="w-4 h-4 text-pink-500 animate-bounce" />
          <span>Buka Langsung Kejutan ✨</span>
        </button>
      </div>
    </div>
  );
};
