import React, { useState } from 'react';
import { Camera, Maximize2, X, Sparkles, Heart, Image as ImageIcon } from 'lucide-react';
import { GALLERY_PHOTOS } from '../data/content';
import { PhotoItem } from '../types';

export const PhotoGallery: React.FC = () => {
  const [selectedPhoto, setSelectedPhoto] = useState<PhotoItem | null>(null);

  return (
    <div className="relative my-16 max-w-5xl mx-auto px-4">
      {/* Section Title */}
      <div className="text-center mb-10">
        <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/80 border border-pink-300 shadow-sm text-pink-700 text-xs font-bold uppercase tracking-wider mb-3">
          <Camera className="w-3.5 h-3.5 text-pink-500" />
          <span>Aesthetic Photo Collection 🌸</span>
        </div>
        <h2 className="text-3xl sm:text-4xl font-serif-title font-bold text-pink-900 tracking-tight">
          Galeri Kenangan & Keindahan
        </h2>
        <p className="mt-2 text-sm text-pink-700 max-w-md mx-auto">
          Klik pada foto untuk melihat tampilan penuh yang memukau.
        </p>
      </div>

      {/* Polaroid Grid Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-8">
        {GALLERY_PHOTOS.map((photo, idx) => (
          <div
            key={photo.id}
            onClick={() => setSelectedPhoto(photo)}
            className="polaroid-card group relative bg-white/90 p-4 pb-6 rounded-3xl shadow-xl border border-pink-100 cursor-pointer transform transition-all duration-300 hover:z-20"
            style={{
              transform: `rotate(${idx % 2 === 0 ? '-2deg' : '2deg'})`
            }}
          >
            {/* Image Wrapper */}
            <div className="relative aspect-[4/5] rounded-2xl overflow-hidden bg-pink-100 mb-4 shadow-inner">
              <img
                src={photo.url}
                alt={photo.title}
                loading="lazy"
                className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110"
                onError={(e) => {
                  // Fallback visual in case network blocks
                  (e.target as HTMLElement).style.display = 'none';
                }}
              />

              {/* Reflection Shine */}
              <div className="absolute inset-0 bg-gradient-to-tr from-pink-500/10 via-transparent to-white/30 opacity-0 group-hover:opacity-100 transition-opacity duration-300 pointer-events-none" />

              {/* Top Corner Badge */}
              <div className="absolute top-3 left-3 px-3 py-1 rounded-full bg-white/80 backdrop-blur-md border border-pink-200 text-[10px] font-bold text-pink-800 shadow-sm flex items-center gap-1">
                <Sparkles className="w-3 h-3 text-amber-400" />
                <span>{photo.dateTag}</span>
              </div>

              {/* Expand Icon Hover Button */}
              <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                <div className="p-3 rounded-full bg-white/90 text-pink-600 shadow-lg transform scale-75 group-hover:scale-100 transition-transform">
                  <Maximize2 className="w-5 h-5" />
                </div>
              </div>
            </div>

            {/* Polaroid Handwritten Caption Area */}
            <div className="text-center px-2">
              <h4 className="text-lg font-serif-title font-bold text-pink-900 group-hover:text-pink-600 transition">
                {photo.title}
              </h4>
              <p className="mt-1 text-xs text-pink-700 font-handwriting text-base line-clamp-2 leading-relaxed">
                "{photo.caption}"
              </p>
            </div>
          </div>
        ))}
      </div>

      {/* Lightbox Modal */}
      {selectedPhoto && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/70 backdrop-blur-md animate-fade-in">
          <div className="relative max-w-2xl w-full bg-white/95 rounded-3xl p-6 border border-pink-200 shadow-2xl overflow-hidden animate-float-bounce">
            {/* Close Button */}
            <button
              onClick={() => setSelectedPhoto(null)}
              className="absolute top-4 right-4 p-2 rounded-full bg-pink-100 hover:bg-pink-200 text-pink-800 transition z-10 cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex flex-col md:flex-row gap-6 items-center">
              {/* Photo Display */}
              <div className="w-full md:w-1/2 aspect-[4/5] rounded-2xl overflow-hidden bg-pink-100 shadow-md">
                <img
                  src={selectedPhoto.url}
                  alt={selectedPhoto.title}
                  className="w-full h-full object-cover"
                />
              </div>

              {/* Details & Caption */}
              <div className="w-full md:w-1/2 flex flex-col justify-between">
                <div>
                  <span className="inline-block px-3 py-1 rounded-full bg-pink-100 text-pink-700 text-xs font-bold mb-2">
                    ✨ {selectedPhoto.dateTag}
                  </span>
                  <h3 className="text-2xl font-serif-title font-bold text-pink-900 mb-3">
                    {selectedPhoto.title}
                  </h3>
                  <p className="text-sm text-pink-800 leading-relaxed font-handwriting text-xl mb-4">
                    "{selectedPhoto.caption}"
                  </p>
                </div>

                <div className="pt-4 border-t border-pink-200 flex items-center justify-between text-xs text-pink-600 font-medium">
                  <span className="flex items-center gap-1">
                    <ImageIcon className="w-3.5 h-3.5 text-pink-500" /> {selectedPhoto.location}
                  </span>
                  <span className="flex items-center gap-1 text-pink-500 font-bold">
                    <Heart className="w-3.5 h-3.5 fill-pink-400" /> Sweet Memories
                  </span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
