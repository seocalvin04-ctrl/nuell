import React, { useState, useEffect } from 'react';
import { Sparkles, Heart, Gift, ArrowRight } from 'lucide-react';

interface OpeningCinematicProps {
  onOpenSurprise: () => void;
}

export const OpeningCinematic: React.FC<OpeningCinematicProps> = ({ onOpenSurprise }) => {
  const [step, setStep] = useState<number>(0);
  const [typedText, setTypedText] = useState<string>('');

  const sentences = [
    "Hi.",
    "Before you continue...",
    "I made something simple.",
    "I hope it brings a smile."
  ];

  useEffect(() => {
    let timeoutId: NodeJS.Timeout;
    const currentSentence = sentences[step];

    if (!currentSentence) return;

    let charIndex = 0;
    setTypedText('');

    const typeInterval = setInterval(() => {
      if (charIndex <= currentSentence.length) {
        setTypedText(currentSentence.slice(0, charIndex));
        charIndex++;
      } else {
        clearInterval(typeInterval);
        // Wait before showing next line or button
        timeoutId = setTimeout(() => {
          if (step < sentences.length - 1) {
            setStep((prev) => prev + 1);
          } else {
            // Reached final sentence, show button step (step = 4)
            setStep(sentences.length);
          }
        }, 1200);
      }
    }, 90);

    return () => {
      clearInterval(typeInterval);
      clearTimeout(timeoutId);
    };
  }, [step]);

  return (
    <div className="relative min-h-screen flex flex-col items-center justify-center p-6 text-center select-none overflow-hidden">
      {/* Soft Light Burst Rays Background */}
      <div className="absolute inset-0 bg-radial-gradient from-pink-200/30 via-transparent to-transparent pointer-events-none" />

      {/* Center Container Card */}
      <div className="relative z-10 max-w-lg w-full flex flex-col items-center justify-center min-h-[320px]">
        {/* Floating Teddy / Heart Icon Decor */}
        <div className="mb-8 animate-float-slow">
          <div className="relative inline-flex items-center justify-center p-4 rounded-full bg-white/70 backdrop-blur-md border border-pink-200 shadow-xl">
            <Heart className="w-10 h-10 text-pink-500 fill-pink-300 animate-pulse" />
            <Sparkles className="absolute -top-1 -right-1 w-5 h-5 text-amber-400 animate-spin" style={{ animationDuration: '5s' }} />
          </div>
        </div>

        {/* Typed Sentence Container */}
        <div className="min-h-[100px] flex flex-col items-center justify-center">
          <h1 className="text-3xl sm:text-5xl font-serif-title font-bold text-pink-900 tracking-tight leading-snug drop-shadow-sm">
            {typedText}
            {step < sentences.length && (
              <span className="inline-block w-1 h-8 ml-1 bg-pink-500 animate-pulse" />
            )}
          </h1>

          {/* Subtitle Soft Glow Notes */}
          {step >= 1 && (
            <p className="mt-3 text-sm sm:text-base text-pink-700 font-medium font-handwriting text-xl animate-fade-in">
              "A Little Surprise Just For You 🤍"
            </p>
          )}
        </div>

        {/* Surprise Button Reveal */}
        {step >= sentences.length && (
          <div className="mt-10 animate-fade-in flex flex-col items-center gap-3">
            <button
              onClick={onOpenSurprise}
              className="group relative inline-flex items-center gap-3 px-8 py-4 rounded-full bg-gradient-to-r from-pink-500 via-rose-400 to-pink-500 text-white font-bold text-base sm:text-lg shadow-xl shadow-pink-400/40 hover:shadow-2xl hover:shadow-pink-400/60 transition-all duration-300 transform hover:scale-105 active:scale-95 cursor-pointer overflow-hidden border border-white/40"
            >
              {/* Shimmer overlay */}
              <span className="absolute inset-0 bg-white/20 transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-1000" />
              
              <Gift className="w-6 h-6 text-yellow-200 animate-bounce" />
              <span className="tracking-wide">✨ Open The Surprise</span>
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </button>

            <span className="text-xs text-pink-600/80 font-medium">
              Klik untuk membuka seluruh kejutan & animasi manis 🌸
            </span>
          </div>
        )}
      </div>
    </div>
  );
};
