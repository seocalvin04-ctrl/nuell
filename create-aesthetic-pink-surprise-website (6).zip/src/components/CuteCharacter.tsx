import React, { useState } from 'react';
import { Sparkles } from 'lucide-react';
import confetti from 'canvas-confetti';

interface CuteCharacterProps {
  onSpeak?: (message: string) => void;
}

export const CuteCharacter: React.FC<CuteCharacterProps> = ({ onSpeak }) => {
  const [bubbleText, setBubbleText] = useState<string>("Halo Kamu! 🧸✨ Sentuh aku yaa...");
  const [isJumping, setIsJumping] = useState<boolean>(false);
  const [activeTab, setActiveTab] = useState<'bear' | 'bunny'>('bear');

  const bearQuotes = [
    "Halo Kamu! Semoga harimu penuh kehangatan yaa! 🤍🧸",
    "Jangan lupa senyum hari ini! Senyummu tuh manis banget! 🌸",
    "Kalau kamu merasa capek, istirahat sejenak yaa... 🫂",
    "Kamu berharga dan hebat banget! Terus berjuang! ✨",
    "Semoga mimpi-mimpimu segera mendekat satu per satu! 🌈",
    "Satu kebaikan kecil bisa mengubah harimu jadi indah! 🌷"
  ];

  const bunnyQuotes = [
    "Haiiii! Kelinci cute siap menemani harimu! 🐰💖",
    "Ingat yaa, pelangi selalu datang setelah hujan! 🌈✨",
    "Makan makanan enak & minum air putih secukupnya yaa! 🍓",
    "Kamu itu spesies jiwa yang sangat luar biasa indah! 🌸",
    "Hugggsss hangat buat kamu dari jauh! 🧸🤍"
  ];

  const handleCharacterTap = (e: React.MouseEvent) => {
    setIsJumping(true);
    setTimeout(() => setIsJumping(false), 800);

    const quotes = activeTab === 'bear' ? bearQuotes : bunnyQuotes;
    const randomQuote = quotes[Math.floor(Math.random() * quotes.length)];
    setBubbleText(randomQuote);
    if (onSpeak) onSpeak(randomQuote);

    // Heart Fireworks from character position
    const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
    const x = (rect.left + rect.width / 2) / window.innerWidth;
    const y = (rect.top + rect.height / 2) / window.innerHeight;

    confetti({
      particleCount: 15,
      spread: 60,
      origin: { x, y },
      colors: ['#f472b6', '#fb7185', '#fce7f3', '#ffd1dc'],
      shapes: ['circle'],
      scalar: 0.8
    });
  };

  return (
    <div className="fixed bottom-5 right-4 z-40 flex flex-col items-end pointer-events-auto select-none group">
      {/* Speech Bubble */}
      <div className="relative mb-2 max-w-[220px] sm:max-w-[280px] bg-white/90 backdrop-blur-md border border-pink-200 text-pink-900 rounded-2xl p-3 shadow-lg text-xs sm:text-sm font-medium animate-float-slow transition-all duration-300 transform group-hover:scale-105">
        <div className="flex items-start gap-1.5">
          <Sparkles className="w-4 h-4 text-pink-500 shrink-0 mt-0.5 animate-spin" style={{ animationDuration: '6s' }} />
          <p className="leading-snug">{bubbleText}</p>
        </div>
        {/* Tail */}
        <div className="absolute -bottom-2 right-6 w-4 h-4 bg-white/90 border-r border-b border-pink-200 transform rotate-45" />
      </div>

      {/* Character Switcher Pill */}
      <div className="flex items-center gap-1 mb-1.5 bg-white/70 backdrop-blur-md border border-pink-200 rounded-full p-1 shadow-sm text-xs font-semibold">
        <button
          onClick={() => { setActiveTab('bear'); setBubbleText("Yeyyy, Teddy Bear kembali! 🧸✨"); }}
          className={`px-2.5 py-0.5 rounded-full transition-all ${
            activeTab === 'bear' ? 'bg-pink-400 text-white shadow-sm' : 'text-pink-600 hover:bg-pink-100'
          }`}
        >
          🧸 Bear
        </button>
        <button
          onClick={() => { setActiveTab('bunny'); setBubbleText("Yeyyy, Bunny cute datang! 🐰💖"); }}
          className={`px-2.5 py-0.5 rounded-full transition-all ${
            activeTab === 'bunny' ? 'bg-pink-400 text-white shadow-sm' : 'text-pink-600 hover:bg-pink-100'
          }`}
        >
          🐰 Bunny
        </button>
      </div>

      {/* Animated Character Graphic */}
      <div
        onClick={handleCharacterTap}
        className={`cursor-pointer transition-transform duration-300 transform hover:scale-110 active:scale-95 ${
          isJumping ? 'animate-bounce' : ''
        }`}
        title="Klik aku untuk kejutan!"
      >
        {activeTab === 'bear' ? (
          /* Animated Soft Pink Teddy Bear SVG */
          <svg className="w-20 h-20 sm:w-24 sm:h-24 drop-shadow-xl" viewBox="0 0 120 120" fill="none">
            {/* Bear Ears */}
            <circle cx="35" cy="35" r="16" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
            <circle cx="35" cy="35" r="9" fill="#fce7f3" />
            <circle cx="85" cy="35" r="16" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
            <circle cx="85" cy="35" r="9" fill="#fce7f3" />
            
            {/* Bear Head */}
            <circle cx="60" cy="55" r="34" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
            
            {/* Bear Snout */}
            <ellipse cx="60" cy="62" rx="14" ry="10" fill="#fff" stroke="#f9a8d4" strokeWidth="2" />
            <ellipse cx="60" cy="58" rx="5" ry="3.5" fill="#db2777" />
            {/* Mouth */}
            <path d="M 56 62 Q 60 66 64 62" stroke="#db2777" strokeWidth="2" strokeLinecap="round" fill="none" />

            {/* Bear Eyes */}
            <circle cx="48" cy="50" r="3.5" fill="#4a044e" />
            <circle cx="49" cy="48.5" r="1" fill="#ffffff" />
            <circle cx="72" cy="50" r="3.5" fill="#4a044e" />
            <circle cx="73" cy="48.5" r="1" fill="#ffffff" />

            {/* Cheeks */}
            <ellipse cx="40" cy="58" rx="5" ry="3" fill="#f472b6" opacity="0.6" />
            <ellipse cx="80" cy="58" rx="5" ry="3" fill="#f472b6" opacity="0.6" />

            {/* Bear Body */}
            <path d="M 38 80 Q 60 70 82 80 C 90 100 80 115 60 115 C 40 115 30 100 38 80 Z" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
            
            {/* Heart on chest */}
            <path d="M 60 88 C 55 83 48 88 52 94 L 60 102 L 68 94 C 72 88 65 83 60 88 Z" fill="#ec4899" className="animate-pulse" />
          </svg>
        ) : (
          /* Animated Soft Pink Bunny SVG */
          <svg className="w-20 h-20 sm:w-24 sm:h-24 drop-shadow-xl" viewBox="0 0 120 120" fill="none">
            {/* Bunny Long Ears */}
            <path d="M 40 45 C 30 10 40 0 48 10 C 52 25 45 40 45 45 Z" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
            <path d="M 41 38 C 34 15 41 8 46 15 C 49 25 44 35 44 38 Z" fill="#fce7f3" />

            <path d="M 80 45 C 90 10 80 0 72 10 C 68 25 75 40 75 45 Z" fill="#fbcfe8" stroke="#f472b6" strokeWidth="3" />
            <path d="M 79 38 C 86 15 79 8 74 15 C 71 25 76 35 76 38 Z" fill="#fce7f3" />

            {/* Bunny Head */}
            <circle cx="60" cy="60" r="32" fill="#fff0f5" stroke="#f472b6" strokeWidth="3" />

            {/* Eyes */}
            <ellipse cx="48" cy="56" rx="3.5" ry="4.5" fill="#4a044e" />
            <circle cx="49" cy="54" r="1.2" fill="#ffffff" />
            <ellipse cx="72" cy="56" rx="3.5" ry="4.5" fill="#4a044e" />
            <circle cx="73" cy="54" r="1.2" fill="#ffffff" />

            {/* Nose & Mouth */}
            <path d="M 58 63 L 62 63 L 60 66 Z" fill="#ec4899" />
            <path d="M 56 68 Q 60 71 64 68" stroke="#db2777" strokeWidth="2" strokeLinecap="round" fill="none" />

            {/* Cute Cheeks */}
            <circle cx="40" cy="62" r="5" fill="#f472b6" opacity="0.6" />
            <circle cx="80" cy="62" r="5" fill="#f472b6" opacity="0.6" />

            {/* Flower Ribbon on Ear */}
            <circle cx="76" cy="40" r="5" fill="#f472b6" />
            <circle cx="76" cy="40" r="2" fill="#fef08a" />
          </svg>
        )}
      </div>
    </div>
  );
};
