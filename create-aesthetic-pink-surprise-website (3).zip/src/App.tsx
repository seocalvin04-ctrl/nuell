import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  Volume2,
  VolumeX,
  ChevronLeft,
  ChevronRight,
  Heart,
  Sparkles,
  Music,
  Image as ImageIcon,
  BookOpen,
  Gift,
  Smile,
  Cloud,
  X,
  Compass,
  Calendar
} from 'lucide-react';

// --- TS Interfaces ---
interface Firework {
  x: number;
  y: number;
  targetX: number;
  targetY: number;
  distanceToTarget: number;
  distanceTraveled: number;
  coordinates: [number, number][];
  coordinateCount: number;
  angle: number;
  speed: number;
  acceleration: number;
  brightness: number;
  alpha: number;
  hue: number;
  type: 'heart' | 'sparkle' | 'normal';
}

interface Particle {
  x: number;
  y: number;
  coordinates: [number, number][];
  coordinateCount: number;
  angle: number;
  speed: number;
  friction: number;
  gravity: number;
  hue: number;
  brightness: number;
  decay: number;
  alpha: number;
  size: number;
  type: 'heart' | 'sparkle' | 'normal';
}

interface CanvasPetal {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  angle: number;
  spin: number;
  opacity: number;
}

interface CanvasBubble {
  x: number;
  y: number;
  size: number;
  speedY: number;
  speedX: number;
  opacity: number;
}

interface CanvasStar {
  x: number;
  y: number;
  size: number;
  speedY: number;
  opacity: number;
  twinkleSpeed: number;
  phase: number;
}

// --- Data Declarations ---
const SURPRISE_TEXT_PAGES = [
  {
    title: "✨ Just For Vitaaaaaaa 🤍",
    subtitle: "A Little Surprise 🌸",
    content: [
      "Allooooooooooooooooooooooooowwwwwwwww Vitaaaaaaa... 🤍🧸🌷🌸🫧✨💐🌼🤍",
      "Hayiieeeeeeeeeeeeeeeeeeeee Vitaaaaaaa... ☀️🤍🌷🧸🌸🫧💌✨🕊️🌼",
      "Hari ini Nuell datang bukan membawa hadiah yang dibungkus pita... 🎀🤍",
      "Bukan membawa bunga yang suatu hari akan layu... 🌹🌷🌸",
      "Bukan juga membawa sesuatu yang mahal... 💐✨",
      "Nuell cuma membawa beberapa lembar kata...",
      "Yang mungkin sederhana...",
      "Yang mungkin tidak bisa menyamai indahnya sebuah hadiah...",
      "Tetapi setiap hurufnya ditulis dengan rasa hormat, ketulusan, dan harapan baik untuk Vitaaaaaaa... 🤍🧸🫶🏻🌼✨"
    ]
  },
  {
    title: "🌍 Tentang Pertemuan Kita",
    subtitle: "Dunia ini Begitu Luas... 🤍",
    content: [
      "Lucu yaa... 🌿☀️",
      "Dunia ini begitu luas... 🌍🤍",
      "Manusia begitu banyak... 🌎🕊️",
      "Setiap hari ada jutaan orang yang saling bertemu, saling menyapa, lalu kembali berjalan dengan jalannya masing-masing...",
      "Namun dari semua kemungkinan itu...",
      "Allah tetap mempertemukan kita dengan orang-orang tertentu...",
      "Yang tanpa sadar mampu meninggalkan kesan yang tidak mudah dilupakan...",
      "Dan menurut Nuell...",
      "Vitaaaaaaa adalah salah satu orang yang membawa kesan itu... 🤍🌸🦋✨"
    ]
  },
  {
    title: "⭐ Kehadiran yang Menenangkan",
    subtitle: "You Are A Warm Light 🌟",
    content: [
      "Ada orang yang dikenal karena prestasinya... ⭐",
      "Ada yang dikenal karena kepintarannya... 📚✨",
      "Ada yang dikenal karena apa yang dimilikinya... 🌼",
      "Tapi...",
      "Ada juga orang yang selalu diingat...",
      "Karena tutur katanya yang menenangkan...",
      "Karena caranya memperlakukan orang lain...",
      "Karena kehadirannya membuat suasana menjadi lebih hangat...",
      "Lebih nyaman...",
      "Dan lebih tenang...",
      "Tanpa harus berusaha menjadi siapa-siapa selain dirinya sendiri... 🤍🌷🫶🏻🧸"
    ]
  },
  {
    title: "🦋 Beautiful Lessons",
    subtitle: "A Beautiful Feeling In Our Hearts ☁️",
    content: [
      "You know...? 🤍✨",
      "Some people...",
      "Don't enter our lives to stay forever...",
      "They come...",
      "To leave beautiful lessons...",
      "Beautiful memories...",
      "And beautiful feelings that quietly remain inside our hearts...",
      "No matter how much time passes...",
      "Even when conversations become fewer...",
      "The kindness they once gave will always have a place to live inside someone's memories... ☁️🤍🌸🦋✨"
    ]
  },
  {
    title: "😊 Harapan Terbaik",
    subtitle: "Never Lose Your Smile 🌟",
    content: [
      "Nuell berharap...",
      "Jangan pernah berubah menjadi orang yang kehilangan senyumnya... 😊🤍",
      "Jangan pernah berhenti menjadi pribadi yang baik... 🌷",
      "Jangan pernah lelah menyebarkan kebaikan...",
      "Walaupun dunia terkadang tidak selalu membalasnya dengan cara yang sama...",
      "Karena setiap kebaikan...",
      "Pasti Allah lihat...",
      "Dan setiap ketulusan...",
      "Pasti Allah simpan menjadi sesuatu yang jauh lebih indah daripada yang kita bayangkan... 🕊️🌼🤍✨"
    ]
  },
  {
    title: "📜 A Special Quote",
    subtitle: "Choosing Kindness Always ☀️",
    content: [
      "A little quote for Vitaaaaaaa... 🤍🌸",
      "\"The most beautiful people are not those who have perfect lives...",
      "They are the ones who keep choosing kindness, even after life teaches them many difficult lessons.\" 🤍☀️🕊️",
      "Dan menurut Nuell...",
      "Kalimat itu begitu indah...",
      "Karena mengingatkan Nuell pada seseorang bernama Vitaaaaaaa...",
      "Seseorang yang semoga akan selalu mempertahankan hatinya yang baik, apa pun yang nanti terjadi dalam perjalanan hidupnya... 🌷🧸✨🤍"
    ]
  },
  {
    title: "💖 Rasa Terima Kasih",
    subtitle: "Thank You For Existing 🫶🏻",
    content: [
      "Terima kasih yaa... 🤍",
      "Terima kasih karena sudah hadir... 🌷",
      "Terima kasih karena tetap menjadi diri sendiri... 🌸",
      "Terima kasih karena tanpa sadar...",
      "Sudah menjadi salah satu orang yang layak dihargai...",
      "Bukan karena kesempurnaan...",
      "Tetapi karena ketulusan yang ada di dalam hati...",
      "Karena di dunia yang serba cepat ini...",
      "Orang yang tetap memilih menjadi baik adalah seseorang yang sangat berharga... 🕊️🤍🫶🏻✨"
    ]
  },
  {
    title: "🌈 Di Balik Awan Kelabu",
    subtitle: "There is Always a Sunny Day ☀️",
    content: [
      "Kalau suatu hari nanti...",
      "Vitaaaaaaa merasa dunia sedang tidak berpihak... 🌧️🤍",
      "Semoga Vitaaaaaaa tetap ingat...",
      "Bahwa setelah hujan...",
      "Langit selalu menemukan caranya untuk kembali cerah... ☀️🌈",
      "Begitu juga dengan hidup...",
      "Tidak ada malam yang selamanya gelap...",
      "Tidak ada kesedihan yang selamanya tinggal...",
      "Dan tidak ada doa yang benar-benar sia-sia ketika disampaikan dengan penuh harapan kepada Allah... 🤍🌸🦋✨"
    ]
  },
  {
    title: "🕊️ Sebuah Kenangan Abadi",
    subtitle: "Sincerely Written from the Heart ✍️",
    content: [
      "Nuell tidak tahu...",
      "Seberapa panjang nanti cerita yang akan kita jalani...",
      "Seberapa sering nanti kita bisa saling menyapa...",
      "Atau ke mana waktu akan membawa langkah kita masing-masing...",
      "Namun satu hal yang Nuell harapkan...",
      "Semoga rasa saling menghargai tetap tinggal...",
      "Semoga kenangan baik tetap menjadi kenangan baik...",
      "Dan semoga ketika suatu hari nanti Vitaaaaaaa membaca pesan ini lagi...",
      "Vitaaaaaaa akan tersenyum dan tahu...",
      "Bahwa pernah ada seseorang bernama Nuell...",
      "Yang benar-benar menuliskan semua ini dengan hati yang tulus... 🤍🧸🌷✨🫶🏻",
      "",
      "Thank you for existing...",
      "Thank you for being yourself...",
      "Keep smiling... 😊🤍",
      "Keep shining... ✨🌸",
      "Keep being kind... 🌷🕊️",
      "And never lose the beautiful heart that makes you... you.",
      "Because this world will always need people who spread warmth without expecting anything in return... ☀️🌍🤍",
      "",
      "Take care, Vitaaaaaaa... 🤍🧸🌷🫧💌🌸✨💐🫶🏻"
    ]
  }
];

export default function App() {
  // --- States ---
  const [loading, setLoading] = useState(true);
  const [progress, setProgress] = useState(0);
  const [loadingMsg, setLoadingMsg] = useState("Menghubungkan sinyal cinta ke galaksi Vita... 📡");
  const [showEnterBtn, setShowEnterBtn] = useState(false);
  const [triggerTransition, setTriggerTransition] = useState(false);
  const [transitionDone, setTransitionDone] = useState(false);
  
  // Custom interactive systems state
  const [currentLetterPage, setCurrentLetterPage] = useState(0);
  const [activeTab, setActiveTab] = useState<'letter' | 'sastra' | 'harmonizer' | 'garden'>('letter');
  
  // Music Player States
  const [isPlaying, setIsPlaying] = useState(false);
  const [duration, setDuration] = useState(0);
  const [currentTime, setCurrentTime] = useState(0);
  const [volume, setVolume] = useState(0.8);
  const [isMuted, setIsMuted] = useState(false);
  const [audioError, setAudioError] = useState<string | null>(null);

  // Polaroid Lightbox State
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [selectedCaption, setSelectedCaption] = useState<string>("");

  // Emotional Harmonizer State
  const [currentMood, setCurrentMood] = useState<'normal' | 'tired' | 'sad' | 'happy' | 'overthinking'>('normal');

  // Garden Blooming State
  const [bloomedFlowers, setBloomedFlowers] = useState<{ [key: string]: boolean }>({});
  const [flowerMessage, setFlowerMessage] = useState<string | null>(null);

  // Interactive Click Sparks
  const [cursorSparkles, setCursorSparkles] = useState<{ id: number; x: number; y: number; char: string; color: string }[]>([]);

  // Birthday date (Fun addition for interactive exploration)
  const [birthDate, setBirthDate] = useState("");
  const [birthFeedback, setBirthFeedback] = useState("");

  // --- Refs ---
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const audioRef = useRef<HTMLAudioElement | null>(null);
  const progressIntervalRef = useRef<number | null>(null);
  const triggerTransitionRef = useRef(false);

  // --- Sound Setup ---
  useEffect(() => {
    // Audio configuration playing MP3
    const audio = new Audio("https://cdn.jsdelivr.net/gh/seocalvin04-ctrl/nuell@main/HIVI!%20-%20Pelangi%20-%20GuanPetteson.mp3");
    audio.crossOrigin = "anonymous";
    audio.loop = true;
    audioRef.current = audio;

    const handleLoadedMetadata = () => {
      setDuration(audio.duration);
    };

    const handleTimeUpdate = () => {
      setCurrentTime(audio.currentTime);
    };

    const handleAudioError = (e: any) => {
      console.error("Audio error encountered:", e);
      // Fallback is graceful in our code: we will display manual trigger option
      setAudioError("Browser memblokir pemutaran otomatis atau file sedang dimuat. Tekan tombol Play untuk mendengarkan.");
    };

    audio.addEventListener('loadedmetadata', handleLoadedMetadata);
    audio.addEventListener('timeupdate', handleTimeUpdate);
    audio.addEventListener('error', handleAudioError);

    return () => {
      audio.removeEventListener('loadedmetadata', handleLoadedMetadata);
      audio.removeEventListener('timeupdate', handleTimeUpdate);
      audio.removeEventListener('error', handleAudioError);
      audio.pause();
    };
  }, []);

  // Update volume
  useEffect(() => {
    if (audioRef.current) {
      audioRef.current.volume = isMuted ? 0 : volume;
    }
  }, [volume, isMuted]);

  // Sync state trigger transition
  useEffect(() => {
    triggerTransitionRef.current = triggerTransition;
  }, [triggerTransition]);

  // --- Progress Bar Loader Simulation ---
  useEffect(() => {
    const messages = [
      { max: 15, text: "Menghubungkan sinyal cinta ke galaksi Vita... 📡" },
      { max: 30, text: "Mengumpulkan kelopak bunga sakura tercantik... 🌸" },
      { max: 45, text: "Menyusun barisan awan kelabu menjadi pelangi... 🌈" },
      { max: 60, text: "Menghangatkan cangkir teh manis penuh rindu... ☕" },
      { max: 75, text: "Mempersiapkan kotak kejutan paling epic sepanjang masa... 🎁" },
      { max: 90, text: "Menyelaraskan melodi indah untuk telinga Vita... 🎵" },
      { max: 100, text: "Semua siap! Ketuk pintu hati Vita sekarang... ✨" }
    ];

    const interval = window.setInterval(() => {
      setProgress((prev) => {
        const next = Math.min(prev + Math.floor(Math.random() * 8) + 2, 100);
        
        // Find matching message
        const matched = messages.find(m => next <= m.max);
        if (matched) {
          setLoadingMsg(matched.text);
        }

        if (next >= 100) {
          clearInterval(interval);
          setShowEnterBtn(true);
        }
        return next;
      });
    }, 180);

    progressIntervalRef.current = interval;
    return () => {
      if (progressIntervalRef.current) clearInterval(progressIntervalRef.current);
    };
  }, []);

  // --- Particle Canvas & Fireworks System ---
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    // Dynamic Lists for Background
    let petals: CanvasPetal[] = [];
    let bubbles: CanvasBubble[] = [];
    let stars: CanvasStar[] = [];
    
    // Dynamic Lists for Cinematic Fireworks
    let fireworks: Firework[] = [];
    let particles: Particle[] = [];

    // Setup function to match current orientation
    const handleResize = () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };
    window.addEventListener('resize', handleResize);

    // Initialize decorative elements
    const createPetals = () => {
      petals = Array.from({ length: 45 }, () => ({
        x: Math.random() * width,
        y: Math.random() * height - height,
        size: Math.random() * 12 + 6,
        speedY: Math.random() * 1.5 + 0.8,
        speedX: Math.random() * 1.2 - 0.6,
        angle: Math.random() * 360,
        spin: Math.random() * 2 - 1,
        opacity: Math.random() * 0.7 + 0.3
      }));
    };

    const createBubbles = () => {
      bubbles = Array.from({ length: 25 }, () => ({
        x: Math.random() * width,
        y: Math.random() * height + height,
        size: Math.random() * 15 + 5,
        speedY: -(Math.random() * 1.0 + 0.4),
        speedX: Math.random() * 0.4 - 0.2,
        opacity: Math.random() * 0.5 + 0.2
      }));
    };

    const createStars = () => {
      stars = Array.from({ length: 50 }, () => ({
        x: Math.random() * width,
        y: Math.random() * height,
        size: Math.random() * 2.5 + 0.5,
        speedY: Math.random() * 0.2 + 0.05,
        opacity: Math.random() * 0.8 + 0.2,
        twinkleSpeed: Math.random() * 0.03 + 0.01,
        phase: Math.random() * Math.PI
      }));
    };

    createPetals();
    createBubbles();
    createStars();

    // Helper to draw cute hearts on canvas
    const drawHeart = (context: CanvasRenderingContext2D, x: number, y: number, size: number, color: string, alpha: number = 1) => {
      context.save();
      context.globalAlpha = alpha;
      context.beginPath();
      context.translate(x, y);
      context.moveTo(0, 0);
      
      // Top curve
      context.bezierCurveTo(-size / 2, -size / 2, -size, size / 3, 0, size);
      context.bezierCurveTo(size, size / 3, size / 2, -size / 2, 0, 0);
      
      context.fillStyle = color;
      context.fill();
      context.restore();
    };

    // Helper to draw cute bubbles on canvas
    const drawBubble = (context: CanvasRenderingContext2D, x: number, y: number, radius: number, alpha: number) => {
      context.save();
      context.globalAlpha = alpha;
      context.beginPath();
      context.arc(x, y, radius, 0, Math.PI * 2);
      
      // Bubble gradient
      const grad = context.createRadialGradient(x - radius/3, y - radius/3, radius * 0.1, x, y, radius);
      grad.addColorStop(0, 'rgba(255, 255, 255, 0.9)');
      grad.addColorStop(0.4, 'rgba(255, 182, 193, 0.4)');
      grad.addColorStop(1, 'rgba(161, 140, 209, 0.15)');
      
      context.fillStyle = grad;
      context.fill();
      
      // Border
      context.strokeStyle = 'rgba(255, 255, 255, 0.4)';
      context.lineWidth = 1;
      context.stroke();
      context.restore();
    };

    // Helper to draw shiny sparkles (4-pointed star)
    const drawSparkle = (context: CanvasRenderingContext2D, x: number, y: number, size: number, color: string, alpha: number) => {
      context.save();
      context.globalAlpha = alpha;
      context.beginPath();
      context.moveTo(x, y - size);
      context.quadraticCurveTo(x, y, x + size, y);
      context.quadraticCurveTo(x, y, x, y + size);
      context.quadraticCurveTo(x, y, x - size, y);
      context.quadraticCurveTo(x, y, x, y - size);
      context.fillStyle = color;
      context.fill();
      context.restore();
    };

    // Firework triggers
    const createExplosion = (x: number, y: number, hue: number, type: 'heart' | 'sparkle' | 'normal' = 'heart') => {
      const particleCount = type === 'heart' ? 45 : 30;
      for (let i = 0; i < particleCount; i++) {
        const angle = (Math.PI * 2 / particleCount) * i;
        const speed = type === 'heart' ? Math.random() * 3 + 1.5 : Math.random() * 5 + 2;
        particles.push({
          x: x,
          y: y,
          coordinates: Array.from({ length: 4 }, () => [x, y]),
          coordinateCount: 4,
          angle: angle,
          speed: speed,
          friction: 0.96,
          gravity: 0.08,
          hue: hue || (Math.floor(Math.random() * 40) + 330),
          brightness: Math.floor(Math.random() * 30) + 70,
          decay: Math.random() * 0.015 + 0.012,
          alpha: 1,
          size: type === 'heart' ? Math.random() * 8 + 4 : Math.random() * 4 + 2,
          type: type
        });
      }
    };

    // Trigger intermittent background fireworks once main content loaded
    let fireworkTimer = 0;

    // --- Main Loop ---
    const tick = () => {
      // Background coloring matching current emotional selection
      let bgGradient = ctx.createLinearGradient(0, 0, 0, height);
      if (currentMood === 'tired') {
        bgGradient.addColorStop(0, '#f3e8ff'); // Lavender tint
        bgGradient.addColorStop(1, '#ffe4e6'); // Light pink
      } else if (currentMood === 'sad') {
        bgGradient.addColorStop(0, '#e0f2fe'); // Soft blue
        bgGradient.addColorStop(1, '#f1f5f9'); // Safe grey
      } else if (currentMood === 'happy') {
        bgGradient.addColorStop(0, '#fffbeb'); // Sun yellow
        bgGradient.addColorStop(1, '#ffe4e6'); // Warm pink
      } else if (currentMood === 'overthinking') {
        bgGradient.addColorStop(0, '#ccfbf1'); // Soft mint/teal
        bgGradient.addColorStop(1, '#f3e8ff'); // Lavender
      } else {
        bgGradient.addColorStop(0, '#fff0f5'); // Lavender blush
        bgGradient.addColorStop(1, '#ffe4e6'); // Pale pink
      }
      ctx.fillStyle = bgGradient;
      ctx.fillRect(0, 0, width, height);

      // --- 1. Draw Stars ---
      stars.forEach((star) => {
        star.phase += star.twinkleSpeed;
        const currentOpacity = star.opacity * (Math.sin(star.phase) * 0.4 + 0.6);
        ctx.save();
        ctx.fillStyle = `rgba(255, 255, 255, ${currentOpacity})`;
        ctx.beginPath();
        ctx.arc(star.x, star.y, star.size, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();

        // Move star down slowly
        star.y += star.speedY;
        if (star.y > height) {
          star.y = -5;
          star.x = Math.random() * width;
        }
      });

      // --- 2. Draw Sakura Petals ---
      petals.forEach((petal) => {
        petal.y += petal.speedY;
        petal.x += petal.speedX;
        petal.angle += petal.spin;

        // Sakura drawing (cute soft shapes)
        ctx.save();
        ctx.translate(petal.x, petal.y);
        ctx.rotate((petal.angle * Math.PI) / 180);
        ctx.globalAlpha = petal.opacity;

        // Custom petal path
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.bezierCurveTo(-petal.size / 2, -petal.size, -petal.size, -petal.size / 2, 0, petal.size / 2);
        ctx.bezierCurveTo(petal.size, -petal.size / 2, petal.size / 2, -petal.size, 0, 0);
        
        ctx.fillStyle = '#ffb7d2'; // Sakura pink
        ctx.fill();

        // White line center of petal
        ctx.strokeStyle = '#fff';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.moveTo(0, 0);
        ctx.lineTo(0, petal.size / 3);
        ctx.stroke();

        ctx.restore();

        // Reset if off bottom
        if (petal.y > height) {
          petal.y = -petal.size;
          petal.x = Math.random() * width;
        }
      });

      // --- 3. Draw Bubbles ---
      bubbles.forEach((bubble) => {
        bubble.y += bubble.speedY;
        bubble.x += bubble.speedX;
        
        drawBubble(ctx, bubble.x, bubble.y, bubble.size, bubble.opacity);

        if (bubble.y < -bubble.size) {
          bubble.y = height + bubble.size;
          bubble.x = Math.random() * width;
        }
      });

      // --- 4. Handle Firecrackers/Fireworks Explosion ---
      if (triggerTransitionRef.current && particles.length === 0 && fireworks.length === 0) {
        // Automatically inject continuous stunning fireworks to celebrate the transition
        for (let i = 0; i < 4; i++) {
          setTimeout(() => {
            createExplosion(
              Math.random() * (width - 200) + 100,
              Math.random() * (height - 300) + 100,
              340,
              Math.random() > 0.5 ? 'heart' : 'sparkle'
            );
          }, i * 350);
        }
      }

      // Render Active Particles
      for (let i = particles.length - 1; i >= 0; i--) {
        const p = particles[i];
        p.speed *= p.friction;
        p.x += Math.cos(p.angle) * p.speed;
        p.y += Math.sin(p.angle) * p.speed + p.gravity;
        p.alpha -= p.decay;

        if (p.alpha <= 0) {
          particles.splice(i, 1);
          continue;
        }

        const colorStr = `hsla(${p.hue}, 100%, ${p.brightness}%, ${p.alpha})`;
        if (p.type === 'heart') {
          drawHeart(ctx, p.x, p.y, p.size, colorStr, p.alpha);
        } else if (p.type === 'sparkle') {
          drawSparkle(ctx, p.x, p.y, p.size, colorStr, p.alpha);
        } else {
          ctx.save();
          ctx.globalAlpha = p.alpha;
          ctx.fillStyle = colorStr;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          ctx.fill();
          ctx.restore();
        }
      }

      // Continuous automatic fireworks in active dashboard (elegant & soft)
      if (transitionDone) {
        fireworkTimer++;
        if (fireworkTimer > 180) { // Every ~3 seconds
          createExplosion(
            Math.random() * (width - 160) + 80,
            Math.random() * (height - 320) + 100,
            330 + Math.random() * 30,
            'sparkle'
          );
          fireworkTimer = 0;
        }
      }

      animationFrameId = requestAnimationFrame(tick);
    };

    tick();

    // Export a globally callable action to let other events spark explosion on click
    (window as any).triggerSparkleExplosion = (x: number, y: number) => {
      createExplosion(x, y, 340, 'heart');
      createExplosion(x, y, 200, 'sparkle');
    };

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
    };
  }, [currentMood, transitionDone]);

  // --- Particle Sparks following Cursor ---
  const handleMouseMove = (e: React.MouseEvent) => {
    if (loading && !showEnterBtn) return;
    const chars = ['🌸', '✨', '💖', '🧸', '🫧', '🤍'];
    const randomChar = chars[Math.floor(Math.random() * chars.length)];
    const colors = ['#ff8ebb', '#fbc2eb', '#a18cd1', '#ffd1e8', '#ffffff'];
    const randomColor = colors[Math.floor(Math.random() * colors.length)];

    const newSparkle = {
      id: Date.now() + Math.random(),
      x: e.clientX,
      y: e.clientY,
      char: randomChar,
      color: randomColor
    };

    setCursorSparkles((prev) => [...prev.slice(-15), newSparkle]); // Cap at 15 items to maintain peak CPU speed
  };

  // Sparkle cleanup timer
  useEffect(() => {
    const timer = setInterval(() => {
      setCursorSparkles((prev) => prev.slice(1));
    }, 120);
    return () => clearInterval(timer);
  }, []);

  // Manual Trigger for Sparkle Burst on general click
  const handlePageClick = (e: React.MouseEvent) => {
    if ((window as any).triggerSparkleExplosion) {
      (window as any).triggerSparkleExplosion(e.clientX, e.clientY);
    }
  };

  // --- Interactive Audio Controls ---
  const handleTogglePlay = () => {
    if (!audioRef.current) return;
    if (isPlaying) {
      audioRef.current.pause();
      setIsPlaying(false);
    } else {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
        setAudioError(null);
      }).catch((e) => {
        console.error("Audio block:", e);
        setAudioError("Tolong izinkan akses media di browsermu agar musik indah ini bisa dimainkan! 💖");
      });
    }
  };

  const handleSeek = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (!audioRef.current) return;
    const value = parseFloat(e.target.value);
    audioRef.current.currentTime = value;
    setCurrentTime(value);
  };

  const handleVolumeChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = parseFloat(e.target.value);
    setVolume(value);
    setIsMuted(value === 0);
  };

  const handleToggleMute = () => {
    setIsMuted(!isMuted);
  };

  // Format seconds to human minutes:seconds
  const formatTime = (secs: number) => {
    if (isNaN(secs)) return "00:00";
    const minutes = Math.floor(secs / 60);
    const seconds = Math.floor(secs % 60);
    return `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
  };

  // --- Surprise Cinematic Screen Unlock ---
  const handleUnlockSurprise = () => {
    setTriggerTransition(true);
    
    // Play the background music automatically on click
    if (audioRef.current) {
      audioRef.current.play().then(() => {
        setIsPlaying(true);
        setAudioError(null);
      }).catch((err) => {
        console.warn("Autoplay blocked, user will play manually in the dashboard.", err);
      });
    }

    // Stage 1: Beautiful explosion fireworks triggered in canvas coordinates
    if ((window as any).triggerSparkleExplosion) {
      (window as any).triggerSparkleExplosion(window.innerWidth / 2, window.innerHeight / 2);
    }

    // Stage 2: Screen Zoom transitions
    setTimeout(() => {
      setLoading(false);
      setTransitionDone(true);
    }, 1800); // Perfect cinematic pause for transition animations
  };

  // --- Flower Blooming Logic ---
  const handleBloomFlower = (flowerId: string, message: string) => {
    setBloomedFlowers(prev => ({ ...prev, [flowerId]: true }));
    setFlowerMessage(message);
    if ((window as any).triggerSparkleExplosion) {
      (window as any).triggerSparkleExplosion(window.innerWidth / 2, window.innerHeight / 2);
    }
  };

  // --- Interactive Birthday Checker ---
  const handleCheckBirthDate = (e: React.FormEvent) => {
    e.preventDefault();
    if (!birthDate) return;
    
    // We can show customized answers or cute easter eggs
    const dateNum = parseInt(birthDate.replace(/\D/g, ''));
    if (birthDate.includes('14') || birthDate.includes('02') || dateNum === 14 || dateNum === 1402) {
      setBirthFeedback("✨ Ya Allah! Apakah hari itu adalah hari di mana bumi mendapatkan salah satu jiwa terlembut dan tercantiknya? Selamat hari lahir, Princess Vitaaaaaaa! 🧸🌸✨ (ID: " + dateNum + ")");
    } else {
      setBirthFeedback("✨ Tanggal berapa pun hari istimewa itu, ketahuilah bahwa kelahiranmu adalah berkat luar biasa yang mendatangkan kebahagiaan dan kehangatan ke dalam dunia! Teruntuk Princess Vitaaaaaaa... 🤍🌈🌷");
    }
  };

  return (
    <div 
      className="min-h-screen relative w-full overflow-x-hidden flex flex-col font-cute select-none"
      onMouseMove={handleMouseMove}
      onClick={handlePageClick}
    >
      {/* Background canvas wrapper (covers loading and normal screen dynamically) */}
      <canvas 
        ref={canvasRef} 
        className="fixed inset-0 w-full h-full pointer-events-none z-0" 
      />

      {/* Floating Sparkle Trail Particles */}
      {cursorSparkles.map((sp) => (
        <span
          key={sp.id}
          className="fixed pointer-events-none text-lg select-none z-50 animate-float transition-all duration-300"
          style={{
            left: sp.x,
            top: sp.y,
            color: sp.color,
            transform: 'translate(-50%, -50%)',
          }}
        >
          {sp.char}
        </span>
      ))}

      {/* =========================================================================
          LOADING SCREEN (Interactive Custom Mascot + Glowing Loader with triggers)
          ========================================================================= */}
      {loading && (
        <div className={`fixed inset-0 z-40 flex flex-col items-center justify-center p-6 bg-[#fff0f5] transition-all duration-1000 ${triggerTransition ? 'slide-in-heart bg-[#ffb7d2]' : ''}`}>
          <div className="relative max-w-lg w-full text-center space-y-8 glassmorphism p-8 rounded-3xl custom-shadow">
            
            {/* Animated Mascot: Cute Teddy Bear (SVG-crafted high premium) */}
            <div className="relative w-44 h-44 mx-auto drop-shadow-md">
              <svg 
                viewBox="0 0 200 200" 
                className="w-full h-full"
                style={{ animation: 'bear-bounce 3.5s infinite ease-in-out' }}
              >
                {/* Bear ears - rotating left & right gently */}
                <g style={{ transformOrigin: '70px 70px', animation: 'bear-ear-left 4s infinite ease-in-out' }}>
                  <circle cx="70" cy="70" r="22" fill="#d19c73" />
                  <circle cx="70" cy="70" r="12" fill="#ffb7d2" />
                </g>
                <g style={{ transformOrigin: '130px 70px', animation: 'bear-ear-right 4s infinite ease-in-out' }}>
                  <circle cx="130" cy="70" r="22" fill="#d19c73" />
                  <circle cx="130" cy="70" r="12" fill="#ffb7d2" />
                </g>

                {/* Bear main face body */}
                <circle cx="100" cy="115" r="48" fill="#d19c73" />

                {/* Eyes: winks & blinks */}
                <circle cx="85" cy="105" r="5" fill="#2d1d15" />
                <circle cx="115" cy="105" r="5" fill="#2d1d15" />
                
                {/* Cheeks: soft glowing pink */}
                <circle cx="74" cy="118" r="7" fill="#ffb7d2" opacity="0.8" className="animate-pulse" />
                <circle cx="126" cy="118" r="7" fill="#ffb7d2" opacity="0.8" className="animate-pulse" />

                {/* Snout */}
                <ellipse cx="100" cy="120" rx="15" ry="11" fill="#fff" />
                {/* Heart-shaped nose */}
                <path d="M100 118 c-1.5 -1.5 -3 -1.5 -4 0 c-1 1 -0.5 2.5 4 4.5 c4.5 -2 5 -3.5 4 -4.5 c-1 -1.5 -2.5 -1.5 -4 0 Z" fill="#ff6a88" />
                <path d="M100 120 L100 126" stroke="#2d1d15" strokeWidth="2" strokeLinecap="round" />

                {/* Left hand - waving at Vita */}
                <g style={{ transformOrigin: '60px 140px', animation: 'arm-wave 2.2s infinite ease-in-out' }}>
                  <ellipse cx="56" cy="142" rx="12" ry="14" fill="#d19c73" />
                  <circle cx="56" cy="136" r="6" fill="#ffb7d2" />
                </g>
                
                {/* Right hand */}
                <ellipse cx="144" cy="142" rx="12" ry="14" fill="#d19c73" />
              </svg>

              {/* Heart floating near mascot */}
              <div className="absolute -top-1 -right-1 text-red-400 text-3xl animate-float-delayed">
                💖
              </div>
              <div className="absolute top-10 -left-6 text-pink-400 text-2xl animate-float">
                🌸
              </div>
            </div>

            {/* Typography & Interactive Progress Loader */}
            <div className="space-y-4">
              <h1 className="text-3xl font-bold tracking-wide text-gradient font-serif">
                𝐉𝐮𝐬𝐭 𝐅𝐨𝐫 𝐕𝐢𝐭𝐚𝐚𝐚𝐚𝐚𝐚 ✨
              </h1>
              <p className="text-sm font-medium text-slate-500 max-w-sm mx-auto leading-relaxed h-12 flex items-center justify-center">
                {loadingMsg}
              </p>

              {/* Progress Container */}
              <div className="w-full bg-[#ffdee9] h-3 rounded-full overflow-hidden relative shadow-inner">
                <div 
                  className="bg-gradient-to-r from-pink-400 to-indigo-400 h-full rounded-full transition-all duration-300 relative"
                  style={{ width: `${progress}%` }}
                >
                  {/* Glowing shimmer */}
                  <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/40 to-transparent animate-pulse" />
                </div>
              </div>
              
              <div className="text-xs font-semibold text-pink-500">
                {progress}% Selesai
              </div>
            </div>

            {/* Glowing Surprise Reveal Trigger */}
            <div className={`transition-all duration-1000 ${showEnterBtn ? 'opacity-100 transform scale-100' : 'opacity-0 transform scale-95 pointer-events-none'}`}>
              <button
                onClick={handleUnlockSurprise}
                className="relative group overflow-hidden px-8 py-4 rounded-full bg-gradient-to-r from-[#ff6a88] to-[#ff99ac] text-white font-bold text-lg tracking-wider shadow-lg hover:shadow-pink-300/50 transition-all duration-300 hover:scale-105 active:scale-95"
                style={{
                  boxShadow: '0 0 20px rgba(255,106,136,0.4)',
                  animation: 'pulse-ring 2s infinite'
                }}
              >
                <span className="relative z-10 flex items-center justify-center gap-2">
                  Buka Kejutan Spesial <Heart className="fill-white w-5 h-5 text-white animate-pulse" />
                </span>
                {/* Hover slide sparkle */}
                <div className="absolute top-0 -inset-full h-full w-1/2 z-50 block transform -skew-x-12 bg-gradient-to-r from-transparent to-white/30 opacity-40 group-hover:animate-[shimmer_1s_ease-in-out]" />
              </button>
            </div>
          </div>
        </div>
      )}


      {/* =========================================================================
          MAIN APPLICATION (Dashboard, interactive systems, music, images, letters)
          ========================================================================= */}
      {!loading && (
        <div className="relative z-10 flex-1 flex flex-col w-full max-w-7xl mx-auto px-4 py-8 md:py-12 gap-8 md:gap-12 animate-[heartTransition_1.2s_ease-out_forwards]">
          
          {/* Top Title Banner */}
          <header className="text-center space-y-3 max-w-xl mx-auto">
            <div className="inline-flex items-center gap-2 px-4 py-1.5 rounded-full bg-white/60 border border-pink-100 text-pink-600 font-bold text-sm shadow-sm animate-float">
              <Sparkles className="w-4 h-4" /> 𝓐 𝓛𝓲𝓽𝓽𝓵𝓮 𝓢𝓾𝓻𝓹𝓻𝓲𝓼𝓮 𝓕𝓸𝓻 𝓥𝓲𝓽𝓪 💖
            </div>
            <h1 className="text-4xl md:text-5xl font-black text-gradient font-serif">
              Just For Vitaaaaaaa
            </h1>
            <p className="text-sm md:text-base font-medium text-slate-500 italic">
              "You are the softest light that turns the coldest night into morning dawn."
            </p>
          </header>

          {/* Grid Layout of the Sanctuary App */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
            
            {/* LEFT COLUMN: Interactive Controls, Music, and Dynamic Polaroid Cards (5 cols) */}
            <div className="lg:col-span-5 space-y-8 h-full">
              
              {/* Premium Music Player */}
              <div className="glassmorphism-premium rounded-3xl p-6 space-y-6 relative overflow-hidden shadow-xl border border-white/70">
                {/* Decorative vinyl or flower */}
                <div className="absolute top-4 right-4 animate-spin-slow">
                  <Music className="text-pink-300 w-8 h-8 opacity-60 animate-bounce" />
                </div>

                <div className="flex items-center gap-4">
                  {/* Rotating CD album art disk */}
                  <div className="relative flex-shrink-0">
                    <div className={`w-16 h-16 rounded-full bg-gradient-to-br from-pink-300 via-indigo-200 to-rose-300 border-2 border-white flex items-center justify-center shadow-lg relative overflow-hidden ${isPlaying ? 'animate-spin' : ''}`} style={{ animationDuration: '8s' }}>
                      <div className="w-5 h-5 rounded-full bg-white border border-pink-200 flex items-center justify-center z-10">
                        <div className="w-1.5 h-1.5 rounded-full bg-pink-400" />
                      </div>
                      {/* CD grooves lines */}
                      <div className="absolute inset-1 border border-black/5 rounded-full" />
                      <div className="absolute inset-3 border border-black/5 rounded-full" />
                    </div>
                    {/* Glowing active indicator */}
                    {isPlaying && (
                      <span className="absolute -top-1 -right-1 flex h-3 w-3">
                        <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-pink-400 opacity-75"></span>
                        <span className="relative inline-flex rounded-full h-3 w-3 bg-pink-500"></span>
                      </span>
                    )}
                  </div>

                  <div>
                    <h3 className="font-bold text-slate-800 text-lg leading-tight">Pelangi</h3>
                    <p className="text-sm font-semibold text-slate-500">HIVI! (GuanPetteson version)</p>
                  </div>
                </div>

                {/* Music Progress Bar */}
                <div className="space-y-1">
                  <input
                    type="range"
                    min="0"
                    max={duration || 100}
                    value={currentTime}
                    onChange={handleSeek}
                    className="w-full accent-pink-500 h-1.5 rounded-lg bg-pink-100 cursor-pointer"
                  />
                  <div className="flex justify-between text-xs font-semibold text-slate-400">
                    <span>{formatTime(currentTime)}</span>
                    <span>{formatTime(duration)}</span>
                  </div>
                </div>

                {/* Custom jump visualizer */}
                <div className="flex justify-center items-end gap-1.5 h-8 w-full px-4 overflow-hidden">
                  {Array.from({ length: 15 }).map((_, i) => {
                    const randomHeight = isPlaying ? Math.random() * 100 : 15;
                    return (
                      <div
                        key={i}
                        className="w-1.5 bg-gradient-to-t from-pink-400 to-indigo-400 rounded-t-full transition-all duration-300"
                        style={{ height: `${randomHeight}%` }}
                      />
                    );
                  })}
                </div>

                {/* Control Buttons */}
                <div className="flex items-center justify-between pt-2">
                  <button
                    onClick={handleToggleMute}
                    className="p-2.5 rounded-full bg-white/80 hover:bg-white text-slate-600 shadow-sm transition-all hover:scale-105 active:scale-95 border border-pink-100"
                  >
                    {isMuted ? <VolumeX className="w-5 h-5 text-red-400" /> : <Volume2 className="w-5 h-5 text-pink-500" />}
                  </button>

                  <button
                    onClick={handleTogglePlay}
                    className="w-14 h-14 rounded-full bg-gradient-to-br from-[#ff6a88] to-[#ff99ac] text-white flex items-center justify-center shadow-lg hover:shadow-pink-300/40 transition-all duration-300 hover:scale-110 active:scale-95"
                  >
                    {isPlaying ? <Pause className="fill-white w-6 h-6" /> : <Play className="fill-white w-6 h-6 ml-0.5" />}
                  </button>

                  <div className="flex items-center gap-1.5">
                    <span className="text-xs font-bold text-slate-400">Vol</span>
                    <input
                      type="range"
                      min="0"
                      max="1"
                      step="0.05"
                      value={volume}
                      onChange={handleVolumeChange}
                      className="w-16 accent-pink-500 h-1 rounded-lg bg-pink-100"
                    />
                  </div>
                </div>

                {audioError && (
                  <p className="text-xs text-center text-pink-500 font-semibold bg-pink-50 p-2.5 rounded-xl border border-pink-100">
                    {audioError}
                  </p>
                )}
              </div>

              {/* Dynamic Polaroid Interactive Photo Cards */}
              <div className="space-y-4">
                <div className="flex items-center gap-2">
                  <ImageIcon className="text-pink-500 w-5 h-5" />
                  <h3 className="font-bold text-slate-800 text-lg">Indahnya Senyummu... ✨</h3>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  {/* Polaroid Card 1 */}
                  <div 
                    onClick={() => {
                      setSelectedImage("https://cdn.jsdelivr.net/gh/seocalvin04-ctrl/nuell@main/file_00000000162481fa869b18adfa3d1111.jpg");
                      setSelectedCaption("Hari ini Nuell membawa sebait doa, di setiap ketulusan tersimpan beribu rasa bahagia untukmu... 🌸");
                    }}
                    className="bg-white p-3 pb-6 rounded-2xl shadow-md border border-pink-100 transform -rotate-2 hover:rotate-0 hover:-translate-y-2 transition-all duration-300 cursor-pointer group hover:shadow-xl relative overflow-hidden"
                  >
                    <div className="aspect-[3/4] rounded-lg overflow-hidden bg-pink-50 relative">
                      <img 
                        src="https://cdn.jsdelivr.net/gh/seocalvin04-ctrl/nuell@main/file_00000000162481fa869b18adfa3d1111.jpg" 
                        alt="Vita" 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        onError={(evt) => {
                          evt.currentTarget.src = "https://images.unsplash.com/photo-1518199266791-5375a83190b7?q=80&w=600";
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-pink-500/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="mt-3 text-center">
                      <p className="text-xs font-cursive text-pink-600 text-lg">Our sweet memory 🌸</p>
                    </div>
                  </div>

                  {/* Polaroid Card 2 */}
                  <div 
                    onClick={() => {
                      setSelectedImage("https://cdn.jsdelivr.net/gh/seocalvin04-ctrl/nuell@main/file_00000000ef0c8207aba9de81ae8f2cec.jpg");
                      setSelectedCaption("You don't enter our lives to stay forever, but you leave feelings that quietly remain inside our hearts... 🤍");
                    }}
                    className="bg-white p-3 pb-6 rounded-2xl shadow-md border border-pink-100 transform rotate-2 hover:rotate-0 hover:-translate-y-2 transition-all duration-300 cursor-pointer group hover:shadow-xl relative overflow-hidden"
                  >
                    <div className="aspect-[3/4] rounded-lg overflow-hidden bg-pink-50 relative">
                      <img 
                        src="https://cdn.jsdelivr.net/gh/seocalvin04-ctrl/nuell@main/file_00000000ef0c8207aba9de81ae8f2cec.jpg" 
                        alt="Vita" 
                        className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                        onError={(e) => {
                          e.currentTarget.src = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?q=80&w=600";
                        }}
                      />
                      <div className="absolute inset-0 bg-gradient-to-t from-pink-500/10 via-transparent to-transparent opacity-0 group-hover:opacity-100 transition-opacity" />
                    </div>
                    <div className="mt-3 text-center">
                      <p className="text-xs font-cursive text-pink-600 text-lg">A beautiful smile ✨</p>
                    </div>
                  </div>
                </div>
                <p className="text-xs text-center text-slate-400 italic">Klik foto untuk melihat dalam resolusi cinematic & pesan tersembunyi 💝</p>
              </div>

              {/* Special Fun Birthday Form */}
              <div className="glassmorphism rounded-3xl p-5 border border-pink-100 shadow-lg space-y-4">
                <div className="flex items-center gap-2">
                  <Calendar className="text-pink-500 w-5 h-5" />
                  <h4 className="font-bold text-slate-800 text-sm">Interactive Birthday Surprise 🎂</h4>
                </div>
                <form onSubmit={handleCheckBirthDate} className="space-y-3">
                  <p className="text-xs text-slate-500 leading-relaxed">
                    Masukkan tanggal lahir istimewa Vita untuk membangkitkan kembang api & pesan khusus dari semesta:
                  </p>
                  <div className="flex gap-2">
                    <input
                      type="text"
                      placeholder="Contoh: 14 Februari"
                      value={birthDate}
                      onChange={(e) => setBirthDate(e.target.value)}
                      className="flex-1 bg-white/70 px-4 py-2 rounded-xl text-sm border border-pink-200 focus:outline-none focus:ring-2 focus:ring-pink-300 transition-all font-medium text-slate-700"
                    />
                    <button
                      type="submit"
                      className="px-4 py-2 bg-pink-400 text-white font-bold text-xs rounded-xl shadow-md hover:bg-pink-500 active:scale-95 transition-all"
                    >
                      Kirim
                    </button>
                  </div>
                </form>

                {birthFeedback && (
                  <div className="bg-white/80 p-3 rounded-xl border border-pink-100 text-xs text-pink-600 font-semibold leading-relaxed animate-float">
                    {birthFeedback}
                  </div>
                )}
              </div>
            </div>

            {/* RIGHT COLUMN: Interactive Surprises with Tabs (7 cols) */}
            <div className="lg:col-span-7 space-y-6">
              
              {/* Magical Tab Bar Menu */}
              <div className="flex gap-2 p-1.5 bg-white/50 border border-white rounded-2xl shadow-inner relative z-10">
                <button
                  onClick={() => setActiveTab('letter')}
                  className={`flex-1 py-3 px-2 rounded-xl font-bold text-xs md:text-sm flex items-center justify-center gap-2 transition-all duration-300 ${activeTab === 'letter' ? 'bg-[#ff8ebb] text-white shadow-md' : 'text-slate-600 hover:bg-white/40'}`}
                >
                  <BookOpen className="w-4 h-4" /> Surat Cinta
                </button>
                <button
                  onClick={() => setActiveTab('sastra')}
                  className={`flex-1 py-3 px-2 rounded-xl font-bold text-xs md:text-sm flex items-center justify-center gap-2 transition-all duration-300 ${activeTab === 'sastra' ? 'bg-[#ff8ebb] text-white shadow-md' : 'text-slate-600 hover:bg-white/40'}`}
                >
                  <Sparkles className="w-4 h-4" /> Sastra & Puisi
                </button>
                <button
                  onClick={() => setActiveTab('harmonizer')}
                  className={`flex-1 py-3 px-2 rounded-xl font-bold text-xs md:text-sm flex items-center justify-center gap-2 transition-all duration-300 ${activeTab === 'harmonizer' ? 'bg-[#ff8ebb] text-white shadow-md' : 'text-slate-600 hover:bg-white/40'}`}
                >
                  <Cloud className="w-4 h-4" /> Mood Harmonizer
                </button>
                <button
                  onClick={() => setActiveTab('garden')}
                  className={`flex-1 py-3 px-2 rounded-xl font-bold text-xs md:text-sm flex items-center justify-center gap-2 transition-all duration-300 ${activeTab === 'garden' ? 'bg-[#ff8ebb] text-white shadow-md' : 'text-slate-600 hover:bg-white/40'}`}
                >
                  <Gift className="w-4 h-4" /> Taman Doa
                </button>
              </div>

              {/* Dynamic Viewport Panel with Framer-like transition effects */}
              <div className="glassmorphism-premium rounded-3xl p-6 md:p-8 min-h-[460px] border border-white shadow-xl relative">
                
                {/* 1. VIEW SURAT CINTA CAROUSEL */}
                {activeTab === 'letter' && (
                  <div className="space-y-6">
                    
                    {/* Header Book Page */}
                    <div className="flex justify-between items-center pb-4 border-b border-pink-100">
                      <div className="space-y-0.5">
                        <span className="text-xs font-bold text-pink-400">BAGIAN {currentLetterPage + 1} DARI {SURPRISE_TEXT_PAGES.length}</span>
                        <h4 className="font-serif font-black text-slate-800 text-xl leading-tight">
                          {SURPRISE_TEXT_PAGES[currentLetterPage].title}
                        </h4>
                        <p className="text-xs font-semibold text-slate-400 italic">
                          {SURPRISE_TEXT_PAGES[currentLetterPage].subtitle}
                        </p>
                      </div>
                      <div className="w-9 h-9 rounded-full bg-pink-50 flex items-center justify-center">
                        <Heart className="w-5 h-5 text-pink-500 fill-pink-300 animate-pulse" />
                      </div>
                    </div>

                    {/* Book Text Panel */}
                    <div className="space-y-4 max-h-[350px] overflow-y-auto pr-2 py-2">
                      {SURPRISE_TEXT_PAGES[currentLetterPage].content.map((line, index) => {
                        if (!line.trim()) return <div key={index} className="h-4" />;
                        return (
                          <p 
                            key={index} 
                            className="text-sm md:text-base text-slate-700 leading-relaxed font-medium select-text tracking-wide hover:translate-x-1 transition-transform"
                          >
                            {line}
                          </p>
                        );
                      })}
                    </div>

                    {/* Book Nav Controls */}
                    <div className="flex items-center justify-between pt-4 border-t border-pink-50">
                      <button
                        onClick={() => {
                          if (currentLetterPage > 0) {
                            setCurrentLetterPage(prev => prev - 1);
                          }
                        }}
                        disabled={currentLetterPage === 0}
                        className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold border transition-all ${currentLetterPage === 0 ? 'border-slate-100 text-slate-300 cursor-not-allowed' : 'border-pink-200 text-pink-600 bg-white hover:bg-pink-50'}`}
                      >
                        <ChevronLeft className="w-4 h-4" /> Kembali
                      </button>

                      <div className="flex gap-1">
                        {SURPRISE_TEXT_PAGES.map((_, i) => (
                          <button
                            key={i}
                            onClick={() => setCurrentLetterPage(i)}
                            className={`w-2 h-2 rounded-full transition-all duration-300 ${currentLetterPage === i ? 'w-5 bg-pink-500' : 'bg-pink-200'}`}
                          />
                        ))}
                      </div>

                      <button
                        onClick={() => {
                          if (currentLetterPage < SURPRISE_TEXT_PAGES.length - 1) {
                            setCurrentLetterPage(prev => prev + 1);
                          }
                        }}
                        disabled={currentLetterPage === SURPRISE_TEXT_PAGES.length - 1}
                        className={`flex items-center gap-1 px-4 py-2 rounded-xl text-sm font-bold border transition-all ${currentLetterPage === SURPRISE_TEXT_PAGES.length - 1 ? 'border-slate-100 text-slate-300 cursor-not-allowed' : 'border-pink-200 text-pink-600 bg-white hover:bg-pink-50'}`}
                      >
                        Lanjut <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>

                  </div>
                )}


                {/* 2. VIEW SASTRA & POEM SANCTUARY */}
                {activeTab === 'sastra' && (
                  <div className="space-y-8">
                    
                    {/* Sastra Section */}
                    <div className="space-y-4 border-b border-pink-100 pb-6">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-pink-100 text-pink-600">Sastra Keindahan</span>
                        <span className="text-pink-400 font-cursive text-lg">Matahari di Balik Embun</span>
                      </div>
                      
                      <h3 className="font-serif font-black text-slate-800 text-xl">
                        Renjana yang Bersemi dalam Sunyi (The Bloom of a Quiet Devotion)
                      </h3>

                      <div className="space-y-3 pl-3 border-l-2 border-pink-200 max-h-[180px] overflow-y-auto pr-2">
                        <p className="text-sm text-slate-600 leading-relaxed select-text italic">
                          "Di balik hiruk-pikuk dunia yang sering kali bising dan terburu-buru, ada keindahan-keindahan sunyi yang luput dari pandangan mata biasa. Bagi Nuell, keindahan itu tidak terletak pada megahnya katedral atau puncak gunung bersalju yang berselimut fajar. Keindahan itu ada pada hal-hal kecil... pada tutur kata yang lembut, pada senyum yang tidak pernah dipaksakan, dan pada ketulusan yang mengalir tenang layaknya air sungai di lereng bukit."
                        </p>
                        <p className="text-sm text-slate-600 leading-relaxed select-text">
                          Sastra ini ditulis khusus untukmu, Vitaaaaaaa. Di belahan bumi mana pun kau melangkah, ketahuilah bahwa kebaikan yang ada dalam dirimu adalah sejenis cahaya. It is the kind of light that doesn't scream for attention, yet it warms anyone who stands nearby. Dalam bahasa Inggris, orang-orang menyebutnya 'grace'—sebuah keanggunan yang lahir bukan dari riasan wajah, melainkan dari kedalaman jiwa yang damai.
                        </p>
                        <p className="text-sm text-slate-600 leading-relaxed select-text">
                          Mungkin kita tidak selalu tahu ke mana takdir akan membawa perahu kecil kita. Roda waktu terus berputar, melahirkan hari-hari baru dengan tantangannya sendiri. Namun, melihatmu tetap menjadi diri sendiri, tetap memilih untuk peduli di tengah dunia yang terkadang dingin, adalah sebuah inspirasi yang tak ternilai. You are like a quiet sanctuary, Vitaaaaaaa. A place where thoughts find rest, and where heartbeats remember how to be kind. Terima kasih telah menjaga keindahan hati itu tetap menyala.
                        </p>
                      </div>
                    </div>

                    {/* Poetry Section */}
                    <div className="space-y-4">
                      <div className="flex items-center gap-2">
                        <span className="px-2.5 py-1 text-xs font-bold rounded-lg bg-indigo-100 text-indigo-600">Poetry Sanctuary</span>
                        <span className="text-indigo-400 font-cursive text-lg">Symphony of Your Soul</span>
                      </div>

                      <h3 className="font-serif font-black text-slate-800 text-xl">
                        Simfoni Jiwa yang Lembut
                      </h3>

                      <div className="space-y-2 text-center py-4 bg-indigo-50/50 rounded-2xl border border-indigo-100/50 max-h-[160px] overflow-y-auto">
                        <p className="text-sm font-serif italic text-indigo-700 leading-relaxed">
                          If kindness were a melody,<br />
                          You would be the softest, most beautiful song.<br />
                          Written in the keys of grace,<br />
                          Played by the wind all night long.
                        </p>
                        <p className="text-xs text-slate-500 font-semibold my-2">— 🌸 —</p>
                        <p className="text-sm text-slate-700 leading-relaxed select-text">
                          Di antara gugurnya daun-daun waktu,<br />
                          Namamu tersimpan rapi dalam doa yang tulus.<br />
                          Bukan karena ingin menggenggam angin,<br />
                          Tapi karena mengagumi sinarmu yang tak pernah pupus.
                        </p>
                        <p className="text-sm text-slate-700 leading-relaxed select-text">
                          You don't have to be perfect to be precious,<br />
                          You don't have to shine like the sun to guide the way.<br />
                          Just being you, with your warm, healing heart,<br />
                          Is enough to turn the darkest night into day.
                        </p>
                        <p className="text-sm font-serif italic text-indigo-700 leading-relaxed mt-2">
                          Maka tersenyumlah, Vitaaaaaaa,<br />
                          Biar bintang-bintang belajar cara bersinar darimu.<br />
                          Sebab di dunia yang fana dan penuh pura-pura ini,<br />
                          Ketulusanmu adalah mutiara yang selalu kurindu.
                        </p>
                      </div>
                    </div>

                  </div>
                )}


                {/* 3. VIEW EMOTION HARMONIZER */}
                {activeTab === 'harmonizer' && (
                  <div className="space-y-6">
                    <div className="space-y-1">
                      <h3 className="font-serif font-black text-slate-800 text-xl">
                        Bagaimana Perasaan Vita Hari Ini? 🧸
                      </h3>
                      <p className="text-xs font-semibold text-slate-500 leading-relaxed">
                        Pilih suasana hatimu saat ini, Nuell siap mengirimkan kehangatan dan menenangkan pikiranmu:
                      </p>
                    </div>

                    {/* Mood Buttons Grid */}
                    <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                      <button
                        onClick={() => {
                          setCurrentMood('tired');
                          if ((window as any).triggerSparkleExplosion) {
                            (window as any).triggerSparkleExplosion(window.innerWidth / 2, window.innerHeight / 2);
                          }
                        }}
                        className={`p-3.5 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all border ${currentMood === 'tired' ? 'bg-purple-100 border-purple-300 text-purple-700 shadow-sm' : 'bg-white hover:bg-slate-50 border-pink-100 text-slate-600'}`}
                      >
                        <span className="text-2xl">😴</span>
                        <span className="font-bold text-xs">Lelah / Tired</span>
                      </button>

                      <button
                        onClick={() => {
                          setCurrentMood('sad');
                          if ((window as any).triggerSparkleExplosion) {
                            (window as any).triggerSparkleExplosion(window.innerWidth / 2, window.innerHeight / 2);
                          }
                        }}
                        className={`p-3.5 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all border ${currentMood === 'sad' ? 'bg-blue-100 border-blue-300 text-blue-700 shadow-sm' : 'bg-white hover:bg-slate-50 border-pink-100 text-slate-600'}`}
                      >
                        <span className="text-2xl">🌧️</span>
                        <span className="font-bold text-xs">Sedih / Sad</span>
                      </button>

                      <button
                        onClick={() => {
                          setCurrentMood('happy');
                          if ((window as any).triggerSparkleExplosion) {
                            (window as any).triggerSparkleExplosion(window.innerWidth / 2, window.innerHeight / 2);
                          }
                        }}
                        className={`p-3.5 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all border ${currentMood === 'happy' ? 'bg-amber-100 border-amber-300 text-amber-700 shadow-sm' : 'bg-white hover:bg-slate-50 border-pink-100 text-slate-600'}`}
                      >
                        <span className="text-2xl">🥰</span>
                        <span className="font-bold text-xs">Senang / Happy</span>
                      </button>

                      <button
                        onClick={() => {
                          setCurrentMood('overthinking');
                          if ((window as any).triggerSparkleExplosion) {
                            (window as any).triggerSparkleExplosion(window.innerWidth / 2, window.innerHeight / 2);
                          }
                        }}
                        className={`p-3.5 rounded-2xl flex flex-col items-center justify-center gap-1.5 transition-all border ${currentMood === 'overthinking' ? 'bg-teal-100 border-teal-300 text-teal-700 shadow-sm' : 'bg-white hover:bg-slate-50 border-pink-100 text-slate-600'}`}
                      >
                        <span className="text-2xl">💭</span>
                        <span className="font-bold text-xs">Overthinking</span>
                      </button>
                    </div>

                    {/* Output mood letters */}
                    <div className="bg-white/85 p-5 rounded-2xl border border-pink-100 shadow-inner relative overflow-hidden min-h-[180px] flex flex-col justify-center">
                      {currentMood === 'tired' && (
                        <div className="space-y-2 animate-float">
                          <span className="text-xs font-bold text-purple-500 uppercase tracking-widest">Pesan Penenang Lelah:</span>
                          <p className="text-sm text-slate-600 leading-relaxed font-medium select-text">
                            "Tarik napas dalam-dalam, Vitaaaaaaa... Kamu telah berjuang sangat hebat hari ini, dan aku sungguh bangga atas segala usahamu. Sekarang, pejamkan matamu sejenak, biarkan melodi manis Pelangi memeluk jiwamu, dan bayangkan selimut dari ribuan bintang hangat membungkusmu malam ini. Istirahatlah, kamu layak mendapat kedamaian..."
                          </p>
                        </div>
                      )}

                      {currentMood === 'sad' && (
                        <div className="space-y-2 animate-float">
                          <span className="text-xs font-bold text-blue-500 uppercase tracking-widest">Pesan Penenang Sedih:</span>
                          <p className="text-sm text-slate-600 leading-relaxed font-medium select-text">
                            "Tidak apa-apa untuk merasa tidak baik-baik saja, Vitaaaaaaa. Bahkan awan di langit pun sesekali butuh menangis sebelum akhirnya menampakkan warna-warni pelangi yang indah. Luapkan saja semua air matamu, namun ingatlah bahwa setelah hujan mereda, sang fajar akan kembali menyapa dengan pelukan hangat. Aku selalu ada di sini untuk mendengar, atau sekadar menemanimu dalam sunyi..."
                          </p>
                        </div>
                      )}

                      {currentMood === 'happy' && (
                        <div className="space-y-2 animate-float">
                          <span className="text-xs font-bold text-amber-500 uppercase tracking-widest">Pesan Perayaan Bahagia:</span>
                          <p className="text-sm text-slate-600 leading-relaxed font-medium select-text">
                            "Mendengar bahwa kamu sedang bahagia membuat duniaku juga ikut bersinar cerah, Vitaaaaaaa! Senyumanmu adalah karya seni terbaik di alam semesta ini. Pertahankan terus pancaran sukacita di wajahmu, bagikan energi positif itu ke bintang-bintang di luar sana, dan mari rayakan hari indah ini dengan hati yang penuh syukur!"
                          </p>
                        </div>
                      )}

                      {currentMood === 'overthinking' && (
                        <div className="space-y-2 animate-float">
                          <span className="text-xs font-bold text-teal-500 uppercase tracking-widest">Pesan Penenang Pikiran:</span>
                          <p className="text-sm text-slate-600 leading-relaxed font-medium select-text">
                            "Hentikan langkah kakimu yang terus berlari kencang di dalam kepalamu, Vitaaaaaaa. Masa depan belum terjadi, dan masa lalu sudah selesai berlalu. Kamu sangat aman dan dilindungi di sini, saat ini juga. Mari tiup pergi segala kekhawatiran itu layaknya meniup gelembung sabun ke udara. Kamu sudah melakukan yang terbaik..."
                          </p>
                        </div>
                      )}

                      {currentMood === 'normal' && (
                        <div className="text-center py-6 text-slate-400">
                          <Smile className="w-10 h-10 mx-auto text-pink-300 animate-bounce mb-2" />
                          <p className="text-sm font-semibold">Silakan klik salah satu tombol emosi di atas untuk mendengarkan bisikan hangat dari Nuell... ✨</p>
                        </div>
                      )}
                    </div>

                    {currentMood !== 'normal' && (
                      <div className="text-center">
                        <button
                          onClick={() => setCurrentMood('normal')}
                          className="text-xs font-bold text-slate-400 hover:text-pink-500 underline transition-all"
                        >
                          Reset Pilihan Mood
                        </button>
                      </div>
                    )}
                  </div>
                )}


                {/* 4. VIEW WISH GARDEN (Bloom virtual flowers) */}
                {activeTab === 'garden' && (
                  <div className="space-y-6">
                    <div className="space-y-1">
                      <h3 className="font-serif font-black text-slate-800 text-xl">
                        Taman Harapan & Doa untuk Vitaaaaaaa 🌷
                      </h3>
                      <p className="text-xs font-semibold text-slate-500 leading-relaxed">
                        Klik pada benih-benih kuncup di bawah ini untuk menumbuhkan bunga-bunga doa ajaib yang akan selalu mekar menemani hari-harimu:
                      </p>
                    </div>

                    <div className="grid grid-cols-2 gap-4 pt-2">
                      {/* Daisy of Peace */}
                      <button
                        onClick={() => handleBloomFlower('daisy', "🌼 Daisy of Peace: Semoga pikiran Vita selalu ditenangkan dari segala kecemasan. May peace always guard your beautiful heart.")}
                        className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 group relative overflow-hidden ${bloomedFlowers['daisy'] ? 'bg-amber-50/70 border-amber-300 shadow-md' : 'bg-white hover:bg-slate-50 border-pink-100'}`}
                      >
                        <span className={`text-4xl transition-all duration-500 ${bloomedFlowers['daisy'] ? 'scale-110 rotate-12' : 'scale-90 opacity-60 grayscale'}`}>
                          🌼
                        </span>
                        <div className="text-center">
                          <p className="font-bold text-xs text-slate-700">Daisy of Peace</p>
                          <span className="text-[10px] font-bold text-pink-400">
                            {bloomedFlowers['daisy'] ? 'Selesai Mekar ✨' : 'Klik untuk Mekar'}
                          </span>
                        </div>
                      </button>

                      {/* Rose of Strength */}
                      <button
                        onClick={() => handleBloomFlower('rose', "🌹 Rose of Strength: Semoga Vita diberikan kekuatan tak terbatas dalam menghadapi segala rintangan. You are stronger than you think!")}
                        className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 group relative overflow-hidden ${bloomedFlowers['rose'] ? 'bg-red-50/70 border-red-300 shadow-md' : 'bg-white hover:bg-slate-50 border-pink-100'}`}
                      >
                        <span className={`text-4xl transition-all duration-500 ${bloomedFlowers['rose'] ? 'scale-110 rotate-12' : 'scale-90 opacity-60 grayscale'}`}>
                          🌹
                        </span>
                        <div className="text-center">
                          <p className="font-bold text-xs text-slate-700">Rose of Strength</p>
                          <span className="text-[10px] font-bold text-pink-400">
                            {bloomedFlowers['rose'] ? 'Selesai Mekar ✨' : 'Klik untuk Mekar'}
                          </span>
                        </div>
                      </button>

                      {/* Sunflower of Joy */}
                      <button
                        onClick={() => handleBloomFlower('sunflower', "🌻 Sunflower of Joy: Semoga hari-hari Vita selalu dipenuhi oleh tawa, keceriaan, dan kehangatan sinar mentari. Keep shining like a sunflower!")}
                        className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 group relative overflow-hidden ${bloomedFlowers['sunflower'] ? 'bg-yellow-50/70 border-yellow-300 shadow-md' : 'bg-white hover:bg-slate-50 border-pink-100'}`}
                      >
                        <span className={`text-4xl transition-all duration-500 ${bloomedFlowers['sunflower'] ? 'scale-110 rotate-12' : 'scale-90 opacity-60 grayscale'}`}>
                          🌻
                        </span>
                        <div className="text-center">
                          <p className="font-bold text-xs text-slate-700">Sunflower of Joy</p>
                          <span className="text-[10px] font-bold text-pink-400">
                            {bloomedFlowers['sunflower'] ? 'Selesai Mekar ✨' : 'Klik untuk Mekar'}
                          </span>
                        </div>
                      </button>

                      {/* Lily of Sincerity */}
                      <button
                        onClick={() => handleBloomFlower('lily', "💮 Lily of Sincerity: Semoga ketulusan yang Vita berikan selalu berbalik menjadi kebaikan berlipat ganda dari Allah. You deserve all the love in the universe.")}
                        className={`p-4 rounded-2xl border transition-all flex flex-col items-center gap-2 group relative overflow-hidden ${bloomedFlowers['lily'] ? 'bg-purple-50/70 border-purple-300 shadow-md' : 'bg-white hover:bg-slate-50 border-pink-100'}`}
                      >
                        <span className={`text-4xl transition-all duration-500 ${bloomedFlowers['lily'] ? 'scale-110 rotate-12' : 'scale-90 opacity-60 grayscale'}`}>
                          💮
                        </span>
                        <div className="text-center">
                          <p className="font-bold text-xs text-slate-700">Lily of Sincerity</p>
                          <span className="text-[10px] font-bold text-pink-400">
                            {bloomedFlowers['lily'] ? 'Selesai Mekar ✨' : 'Klik untuk Mekar'}
                          </span>
                        </div>
                      </button>
                    </div>

                    {/* Display Blooming Wishes Output message */}
                    {flowerMessage && (
                      <div className="bg-[#fff5f8] p-4 rounded-2xl border border-pink-150 shadow-inner relative overflow-hidden animate-float">
                        <div className="absolute top-2 right-2 text-pink-300 text-lg">🌸</div>
                        <p className="text-sm font-semibold text-pink-700 leading-relaxed text-center select-text">
                          {flowerMessage}
                        </p>
                      </div>
                    )}
                  </div>
                )}

              </div>
            </div>

          </div>

          {/* Epic Sastra Part 2 & Literature Cinematic Prose Section */}
          <div className="glassmorphism-premium rounded-3xl p-6 md:p-8 border border-white shadow-xl relative overflow-hidden space-y-6">
            <div className="absolute -top-10 -left-10 w-44 h-44 bg-pink-100/40 rounded-full blur-3xl pointer-events-none" />
            <div className="absolute -bottom-10 -right-10 w-44 h-44 bg-indigo-100/40 rounded-full blur-3xl pointer-events-none" />

            <div className="flex items-center gap-2 pb-4 border-b border-pink-100">
              <Compass className="text-pink-500 w-6 h-6 animate-spin-slow" />
              <div>
                <h3 className="font-serif font-black text-slate-800 text-xl leading-tight">Matahari Senja di Bulan Syukur</h3>
                <p className="text-xs font-bold text-pink-500">A Cinematic Sincere Prose for Princess Vitaaaaaaa 🌸✨</p>
              </div>
            </div>

            <div className="space-y-4 text-slate-700 leading-relaxed text-sm md:text-base select-text">
              <p className="indent-6 font-medium">
                Vitaaaaaaa, have you ever looked up at the night sky and wondered why some stars seem to twinkle brighter than the rest? I think it’s because they carry the dreams of people who love with all their hearts. Whenever you feel tired, when the weight of the world feels too heavy on your shoulders, I want you to look up and remember: you are never truly alone. Ada doa-doa yang selalu mengalir tenang untukmu. Ada harapan-harapan baik yang dipanjatkan di setiap sepertiga malam, memohon agar senyummu tidak pernah pudar, agar hatimu selalu dipeluk oleh kedamaian.
              </p>
              <p className="indent-6 font-medium">
                Kita hidup di zaman di mana orang-orang sering lupa cara mengapresiasi hal-hal sederhana. Tetapi bersamamu, waktu rasanya berjalan lebih lambat. Setiap percakapan, setiap tawa kecil, bahkan keheningan yang tercipta di antara pesan-pesan kita, terasa seperti secangkir kopi hangat di pagi hari yang mendung. Warm, soothing, and incredibly reassuring. You have this magical ability to make things better just by existing.
              </p>
              <p className="indent-6 font-medium">
                Don't ever doubt your worth, Vitaaaaaaa. Don't ever let the harshness of life make you forget how beautiful you are inside. This letter, these words, they are a monument of appreciation for who you are. A reminder that you are deeply valued, respected, and cherished for the beautiful soul that you carry. Keep shining, princess.
              </p>
            </div>
            
            <div className="flex justify-end pt-2">
              <span className="font-cursive text-pink-600 text-3xl">- Segenap Hati, Nuell 🤍🧸</span>
            </div>
          </div>

          {/* Footer of the Sanctuary */}
          <footer className="text-center py-6 text-xs text-slate-400 font-semibold space-y-2">
            <p>Made with absolute love & devotion by Nuell for Princess Vitaaaaaaa 🌸</p>
            <p className="text-[10px] text-slate-300">© 2026. All stars and sakura petals dedicated to your gentle heart.</p>
          </footer>

          {/* Image Zoom Lightbox Portal */}
          {selectedImage && (
            <div 
              className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex flex-col items-center justify-center p-4 animate-fade-in"
              onClick={() => setSelectedImage(null)}
            >
              <div className="relative max-w-xl w-full bg-white p-4 rounded-3xl shadow-2xl space-y-4 animate-scale-up" onClick={(e) => e.stopPropagation()}>
                <button 
                  onClick={() => setSelectedImage(null)}
                  className="absolute top-4 right-4 p-2 rounded-full bg-slate-100 hover:bg-slate-200 text-slate-600 transition-all active:scale-95 z-10"
                >
                  <X className="w-5 h-5" />
                </button>
                <div className="aspect-[3/4] rounded-2xl overflow-hidden bg-slate-100">
                  <img 
                    src={selectedImage} 
                    alt="Enlarged Memory" 
                    className="w-full h-full object-cover"
                    onError={(e) => {
                      e.currentTarget.src = "https://images.unsplash.com/photo-1518199266791-5375a83190b7?q=80&w=600";
                    }}
                  />
                </div>
                <div className="text-center px-2 py-1">
                  <p className="text-sm md:text-base font-semibold text-slate-700 leading-relaxed italic">
                    {selectedCaption}
                  </p>
                  <span className="text-xs text-pink-500 font-bold mt-2 inline-block">Untuk Princess Vitaaaaaaa 💖</span>
                </div>
              </div>
            </div>
          )}

        </div>
      )}
    </div>
  );
}
